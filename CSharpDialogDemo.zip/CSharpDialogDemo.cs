/////////////////////////////////////////////////////////////////////////////
// CSharpDialogDemo.cs                                                     //
//   - demonstrates UI Freezing and use of worker thread to prevent that   //
//   - demonstrates use of Form.Invoke to safely allow worker thread to    //
//     invoke functions on a window                                        //
//                                                                         //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2008         //
/////////////////////////////////////////////////////////////////////////////

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;

namespace CSharpThreads
{
  public class Form1 : System.Windows.Forms.Form
  {
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.RadioButton radioButton1;
    private System.Windows.Forms.RadioButton radioButton2;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.RadioButton radioButton3;
    private System.Windows.Forms.RadioButton radioButton4;
    private System.Windows.Forms.RadioButton radioButton5;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.ComponentModel.Container components = null;

    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
    private static int MaxCount = 50000;
    private volatile bool Stop;
    Thread workerThread = null;

    private delegate void ShowString(string s);
    private delegate void SetFocus();
    private delegate void Counter(int i);
    private event Counter evc;

    public Form1()
    {
      InitializeComponent();
    }

    protected override void Dispose( bool disposing )
    {
      if( disposing )
      {
        if (components != null) 
        {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.radioButton1 = new System.Windows.Forms.RadioButton();
      this.radioButton2 = new System.Windows.Forms.RadioButton();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.radioButton3 = new System.Windows.Forms.RadioButton();
      this.radioButton4 = new System.Windows.Forms.RadioButton();
      this.radioButton5 = new System.Windows.Forms.RadioButton();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.button1 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.groupBox1.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.SuspendLayout();
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(80, 72);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(88, 20);
      this.textBox1.TabIndex = 0;
      this.textBox1.Text = "textBox1";
      this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // textBox2
      // 
      this.textBox2.BackColor = System.Drawing.Color.White;
      this.textBox2.Location = new System.Drawing.Point(80, 144);
      this.textBox2.Name = "textBox2";
      this.textBox2.ReadOnly = true;
      this.textBox2.Size = new System.Drawing.Size(88, 20);
      this.textBox2.TabIndex = 1;
      this.textBox2.Text = "textBox2";
      this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // radioButton1
      // 
      this.radioButton1.Location = new System.Drawing.Point(240, 72);
      this.radioButton1.Name = "radioButton1";
      this.radioButton1.Size = new System.Drawing.Size(48, 24);
      this.radioButton1.TabIndex = 2;
      this.radioButton1.Text = "no";
      // 
      // radioButton2
      // 
      this.radioButton2.Location = new System.Drawing.Point(240, 144);
      this.radioButton2.Name = "radioButton2";
      this.radioButton2.Size = new System.Drawing.Size(48, 24);
      this.radioButton2.TabIndex = 3;
      this.radioButton2.Text = "yes";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.radioButton5,
                                                                            this.radioButton4,
                                                                            this.radioButton3});
      this.groupBox1.Location = new System.Drawing.Point(328, 40);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(144, 168);
      this.groupBox1.TabIndex = 4;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "worker thread priority";
      // 
      // groupBox2
      // 
      this.groupBox2.Location = new System.Drawing.Point(200, 40);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(112, 168);
      this.groupBox2.TabIndex = 5;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "use worker thread";
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.button3,
                                                                            this.button2,
                                                                            this.button1,
                                                                            this.label2,
                                                                            this.label1});
      this.groupBox3.Location = new System.Drawing.Point(40, 16);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(600, 256);
      this.groupBox3.TabIndex = 6;
      this.groupBox3.TabStop = false;
      // 
      // radioButton3
      // 
      this.radioButton3.Location = new System.Drawing.Point(16, 32);
      this.radioButton3.Name = "radioButton3";
      this.radioButton3.TabIndex = 0;
      this.radioButton3.Text = "HIGHEST";
      // 
      // radioButton4
      // 
      this.radioButton4.Location = new System.Drawing.Point(16, 64);
      this.radioButton4.Name = "radioButton4";
      this.radioButton4.TabIndex = 1;
      this.radioButton4.Text = "NORMAL";
      // 
      // radioButton5
      // 
      this.radioButton5.Location = new System.Drawing.Point(16, 104);
      this.radioButton5.Name = "radioButton5";
      this.radioButton5.TabIndex = 2;
      this.radioButton5.Text = "LOWEST";
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(40, 24);
      this.label1.Name = "label1";
      this.label1.TabIndex = 0;
      this.label1.Text = "Max Iterations";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(40, 96);
      this.label2.Name = "label2";
      this.label2.TabIndex = 1;
      this.label2.Text = "Current Iterations";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(480, 48);
      this.button1.Name = "button1";
      this.button1.TabIndex = 2;
      this.button1.Text = "Start";
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(480, 88);
      this.button2.Name = "button2";
      this.button2.TabIndex = 3;
      this.button2.Text = "Stop";
      this.button2.Click += new System.EventHandler(this.button2_Click);
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(480, 128);
      this.button3.Name = "button3";
      this.button3.TabIndex = 4;
      this.button3.Text = "Cancel";
      this.button3.Click += new System.EventHandler(this.button3_Click);
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(680, 317);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox1,
                                                                  this.radioButton2,
                                                                  this.radioButton1,
                                                                  this.textBox2,
                                                                  this.textBox1,
                                                                  this.groupBox2,
                                                                  this.groupBox3});
      this.Name = "Form1";
      this.Text = "Form1";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.groupBox1.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    //
    //----< basic work unit used by main and worker threads >--------

    public void doWork()
    {
      double temp = 1.0/3.0;
      int i, IMax = 5000;
      for(i=0; i<IMax; ++i)
        temp *= 2.5;
    }
    //----< work function used by main thread >----------------------

    public void doWorkMainThread()
    {
      Stop = false;
      this.Text = "Main Thread - Work Running";
      for(int i=0; i<MaxCount; ++i)
      {
        if (Stop)
          break;
        textBox2.Text = i.ToString();
        doWork();
      }
      Stop = true;
      this.Text = "Main Thread - Work Stopped";
      textBox2.Text = MaxCount.ToString();
        textBox1.Focus();
    }
    //----< work function used by worker thread >--------------------

    public void doWorkWorkerThread()
    {
      lock (this) { Stop = false; }

      // worker threads should not directly call functions on
      // windows created by another thread, so use Form.Invoke
      // to make safe, indirect, calls by worker

      string msg = "Worker Thread - Work Running";

      ShowString ss = delegate(string s)  // delegate with anonymous method
      {
        this.Text = s;
      };
      if(this.InvokeRequired)
        this.Invoke(ss, new Object[] { msg });  // Form.Invoke
      else
        ss(msg);

      for(int i=0; i<MaxCount; ++i)
      {
        lock (this)
        {
          if (Stop)
            break;
        }

        if(this.InvokeRequired)
          this.Invoke(evc, new object[] { i });  // conventional delegate
        else                                     // subscription in Form_Load
          evc(i);
        
        doWork();
      }

      lock (this) 
      {
        if (Stop == true)
        {
          msg = "Worker Thread - Work Stopped";
          if (this.InvokeRequired)
            this.Invoke(ss, new Object[] { msg });
          else
            ss(msg);
          
          textBox2.Text = 0.ToString();
        }
        else
        {
          msg = "Worker Thread - Work Completed";
          if (this.InvokeRequired)
            this.Invoke(ss, new Object[] { msg });
          else
            ss(msg);

          Counter cntr = delegate(int count) // delegate with anonymous method
          {
            textBox2.Text = count.ToString();
          };
          if (this.InvokeRequired)
            this.Invoke(cntr, new Object[] { MaxCount });
          else
            cntr(MaxCount);
        }
      }
      SetFocus focus = delegate() { textBox1.Focus(); }; // as above
      if(this.InvokeRequired)
        this.Invoke(focus, new Object[0] );
      else
        focus();
    }
    //
    //----< used by main and worker threads to set iteration count >---

    public void CountHandler(int count)
    {
      textBox2.Text = count.ToString();
    }

    [STAThread]
    static void Main() 
    {
      Application.Run(new Form1());
    }

    //----< initialize form here >-----------------------------------

    private void Form1_Load(object sender, System.EventArgs e)
    {
      textBox1.Text = MaxCount.ToString();
      textBox2.Text = "0";
      evc += new Counter(CountHandler);
      radioButton2.Checked = true;
      radioButton4.Checked = true;
    }
    //----< Start button handler >-----------------------------------

    private void button1_Click(object sender, System.EventArgs e)
    {
      MaxCount = Convert.ToInt32(textBox1.Text);
      textBox2.Text = "0";
      textBox2.Update();
      if(radioButton1.Checked)
        doWorkMainThread();
      else
      {
        workerThread = new Thread(new ThreadStart(doWorkWorkerThread));
        if(radioButton3.Checked)
          workerThread.Priority = ThreadPriority.Highest;
        else if(radioButton4.Checked)
          workerThread.Priority = ThreadPriority.Normal;
        else
          workerThread.Priority = ThreadPriority.Lowest;
        workerThread.Start();
      }
    }
    //----< Stop button handler >------------------------------------

    private void button2_Click(object sender, System.EventArgs e)
    {
      lock (this) { Stop = true; }
    }
    //----< Cancel button handler >----------------------------------

    private void button3_Click(object sender, System.EventArgs e)
    {
      lock (this) { Stop = true; }
      if(workerThread != null)
        workerThread.Abort();
      this.Close();
    }
  }
}
