#include "Tuple.h"
#include <iostream>

int main()
{
  //tuple<double, uint64_t, const char*> t1(12.2, 42, "big");

  //std::cout << "0th elem is " << get<0>(t1) << "\n";
  //std::cout << "1th elem is " << get<1>(t1) << "\n";
  //std::cout << "2th elem is " << get<2>(t1) << "\n";

  //get<1>(t1) = 103;
  //std::cout << "1th elem is " << get<1>(t1) << "\n";
  return 0;
}