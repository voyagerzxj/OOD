#pragma once
///////////////////////////////////////////////////////////////////////////
// Adder.h - simple example of variadic template function                //
// Source:  Eli Bendersky,                                               //
//          https://eli.thegreenplace.net/2014/variadic-templates-in-c/  //
// Adapted: Jim Fawcett, CSE687 - Object Oriented Design, Spring 2018    //
///////////////////////////////////////////////////////////////////////////

template <typename T>
T adder(T t) {
  std::cout << "\n  " << __FUNCSIG__ << "\n";
  return t;
}

template<typename T, typename... Args>
T adder(T first, Args... args) {
  std::cout << "\n  " << __FUNCSIG__;
  return first + adder(args...);
}


