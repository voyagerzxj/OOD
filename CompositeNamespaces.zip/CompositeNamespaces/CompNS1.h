#ifndef COMPNS1_H
#define COMPNS1_H
///////////////////////////////////////////////////////////////////////////////////////
// CompNS1.h - Demonstrate nesting namespaces ADT, Templates, and Inheritance inside //
//             namespace OOD.  Note sequencing of the three inner namespaces.        //
//                                                                                   //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2014                         //
///////////////////////////////////////////////////////////////////////////////////////

#include <iostream>

namespace OOD {

  namespace ADT { // namespaces can be nested

    class Str {
    public:
      Str();
    };

  }

  namespace Templates {  // namespaces can be sequenced too

    template <typename T>
    class Stack {
    public:
      Stack();
    };

    template <typename T>
    Stack<T>::Stack() { 
      std::cout << "\n  constructing instance of OOD::Templates::Stack"; 
    }
  }

  namespace Inheritance {

    struct Interface {
      virtual ~Interface();
    };
  }
}
#endif
