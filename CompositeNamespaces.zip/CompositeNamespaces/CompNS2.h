#ifndef COMPNS2_H
#define COMPNS2_H
/////////////////////////////////////////////////////////////////////////////////////////
// CompNS2.h   - Demonstrate extending namespace OOD beyond the package of its initial //
//               definition, e.g., CompNS1.                                            //
//                                                                                     //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2014                           //
/////////////////////////////////////////////////////////////////////////////////////////

#include "CompNS1.h"

namespace OOD {  // namespaces can be extended in packages other than
                 // that package with the initial declaration

  namespace Polymorphism {

    class Derived : public Inheritance::Interface {
    public:
      Derived();
    };
  }
}
#endif
