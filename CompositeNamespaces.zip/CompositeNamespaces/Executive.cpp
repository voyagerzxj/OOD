///////////////////////////////////////////////////////////////
// Executive.cpp - Demonstrate composite namespaces          //
//                                                           //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2014 //
///////////////////////////////////////////////////////////////

#include "CompNS1.h"
#include "CompNS2.h"

#include <iostream>

#ifdef RUN  // you don't usually put compile guard around executive main

struct Cosmetic {  // display two newlines before exit
  ~Cosmetic() { std::cout << "\n\n"; }
} cosmetic;

void main()
{
  std::cout << "\n  Demonstrating Composite Namespaces";
  std::cout << "\n ====================================\n";

  OOD::ADT::Str s;
  using namespace OOD;
  Templates::Stack<ADT::Str> stk;
  using namespace Inheritance;
  Polymorphism::Derived derived;
}

#endif
