/////////////////////////////////////////////////////////////////////////////////////////
// CompNS1.cpp - Demonstrate nesting namespaces ADT, Templates, and Inheritance inside //
//               namespace OOD.  Note sequencing of the three inner namespaces.        //
//                                                                                     //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2014                           //
/////////////////////////////////////////////////////////////////////////////////////////

#include "CompNS1.h"
#include <iostream>

using namespace OOD::ADT;

Str::Str() { std::cout << "\n  constructing instance of OOD::ADT::Str"; }

using namespace OOD::Inheritance;
Interface::~Interface() { std::cout << "\n  destroying instance of OOD::Inheritance::Interface"; }

#ifdef TEST_COMPNS1

void main()
{
  OOD::ADT::Str s;
  OOD::Templates::Stack<OOD::ADT::Str> stk;
  OOD::Inheritance::Interface someInterface;
}

#endif
