/////////////////////////////////////////////////////////////////////////////////////////
// CompNS2.cpp - Demonstrate extending namespace OOD beyond the package of its initial //
//               definition, e.g., CompNS1.                                            //
//                                                                                     //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2014                           //
/////////////////////////////////////////////////////////////////////////////////////////

#include "CompNS1.h"
#include "CompNS2.h"
#include <iostream>

OOD::Polymorphism::Derived::Derived() { std::cout << "\n  creating instance of OOD::Polymorphism::Derived"; }

#ifdef TEST_COMPNS2

void main()
{
  OOD::Polymorphism::Derived derived;
}
#endif
