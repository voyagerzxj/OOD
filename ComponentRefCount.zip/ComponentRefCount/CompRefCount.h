#ifndef COMPREFCOUNT_H
#define COMPREFCOUNT_H
///////////////////////////////////////////////////////////////
// CompRefCount.h - Demonstrate Reference Counting Helpers   //
// Version 2                                                 //
// Jim Fawcett, CSE775 - Distributed Objects, Spring 2014    //
///////////////////////////////////////////////////////////////

#include <vector>
#include <string>
#include <atomic>  // C++11

/////////////////////////////////////////////////////////////////////////
// Flexible Interface - define results and zero or more arguments
//                      in template declaration

template <typename R, typename ...A>  // C++11 variadic template
struct IComp
{
  virtual ~IComp() {};
  template <typename T>
  static IComp<R, A...>* Create();
  virtual R doOperation(A...) = 0;    // C++11 variadic function
  virtual IComp<R, A...>* AddRef() = 0;
  virtual void Release() = 0;
  virtual void Verbose(bool pred=true) = 0;
};

template <typename R, typename...A>
template <typename T>
IComp<R, A...>* IComp<R, A...>::Create() { return new T(); }

/////////////////////////////////////////////////////////////////////////
// Reference counting wrapper - expects instance to reside on heap

template <typename T>
class AbstractRefCount : public T
{
public:
  AbstractRefCount() { 
    refCnt = 1; 
  }
  T* AddRef() { ++refCnt; return this; }
  void Release() {
    if (--refCnt == 0)
      delete this;
  }
  virtual ~AbstractRefCount() { 
    if (verbose_)
      std::cout << "\n  destroying Reference Counted Instance"; 
  }
protected:
  bool verbose_ = false;
private:
  std::atomic<size_t> refCnt;  // Reference Counting will be thread safe
};

#endif
