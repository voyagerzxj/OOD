///////////////////////////////////////////////////////////////
// CompRefCount.cpp - Demonstrate Reference Counting Helpers //
// Version 2                                                 //
// Jim Fawcett, CSE775 - Distributed Objects, Spring 2014    //
///////////////////////////////////////////////////////////////

#ifdef TEST_COMPREFCOUNT

#include "CompRefCount.h"
#include <iostream>
#include <chrono>   // C++11

struct Cosmetic  // sends newlines to cout before leaving main;
{
  ~Cosmetic() { std::cout << "\n\n"; }
} cosmetic;

/////////////////////////////////////////////////////////////////////////
// Our specific Reference Counted Component

using Result = std::vector<std::string>;  // C++11 aliases
using Path = std::string;
using Patterns = std::vector<std::string>;

using ISearchComponent = IComp<Result, const Path&, const Patterns&>;

class SearchComp : public AbstractRefCount<ISearchComponent>
{
public:
  SearchComp() : AbstractRefCount<ISearchComponent>() {};
  Result doOperation(const Path& path, const Patterns& patterns);
  void Verbose(bool pred = true) { verbose_ = pred; }
  ~SearchComp();
};

SearchComp::~SearchComp()
{
  if (verbose_)
    std::cout << "\n  destroying SearchComp instance";
}

Result SearchComp::doOperation(const Path& path, const Patterns& patterns)
{
  std::cout << "\n  Simulated search with path: " << path << " and patterns: ";
  for (auto patt : patterns)
    std::cout << patt << " ";

  // note: uniform initialization - C++11

  Result result{ path + "/first result", path + "/second result", path + "/third result" };
  return result;
}

/////////////////////////////////////////////////////////////////////////
// Note:
// If you Define a search interface, as done above, then 
// define another with different arguments, you don't break
// clients of the old interface.  You've defined a new 
// interface type and both the clients of the old and the new
// still work.

int main(int argc, char* argv[])
{
  std::cout << "\n  Demonstrating Reference Counting with Search Simulation";
  std::cout << "\n =========================================================\n";

  std::cout << "\n  Command line arguments are: ";
  for (int i = 1; i<argc; ++i)
    std::cout << argv[i] << " ";
  std::cout << std::endl;

  Path path = "foo/bar";
  Patterns patts{ "*.*" };
  if (argc > 1)
  {
    path = argv[1];
    if (argc > 2)
    {
      patts.pop_back();
      for (int i = 2; i < argc; ++i)
        patts.push_back(argv[i]);
    }
  }

  // remember to call release, otherwise get memory leak

  ISearchComponent* pSC1 = ISearchComponent::Create<SearchComp>();
  ISearchComponent* pSC2 = pSC1->AddRef();
  pSC1->Verbose();

  using HRclock = std::chrono::high_resolution_clock;  // C++11 alias
  HRclock::time_point tstart = HRclock::now();
  
  Result result = pSC1->doOperation(path, patts);
  pSC1->Release();  // won't destroy yet;
  
  HRclock::time_point tend = HRclock::now();

  std::chrono::duration<double> time_span 
    = std::chrono::duration_cast<std::chrono::duration<double>>(tend - tstart);
  std::cout << "\n  Execution time = " << time_span.count() << " seconds" << std::endl;

  for (auto item : result)
    std::cout << "\n  " + item;
  std::cout << std::endl;

  pSC2->Release();  // will destroy now

  // Uncomment the lines below to show that you can use local SearchComp.
  // OK to declare on stack, but don't call Release

  // SearchComp searcher;
  // searcher.Verbose();

  return 0;
}

#endif
