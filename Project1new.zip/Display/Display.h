#pragma once
///////////////////////////////////////////////////////////////////////
// Display.h   - class used to display files under certain directory //
//             - using certain application and options               //
// ver 1.0                                                           //
// Xiaojun Zhang, CSE687 - Object Oriented Design, Spring 2019       //
/////////////////////////////////////////////////////////////////////// 

/*
*  Package Operations:
*  -------------------
*  This package provides a class, Display, used to display files under
*  certain directory using certain application and options. 
*  It uses DirExplorerN class to find all files with certain file extension name under certain directory
*  It uses Process class to create child processes to display all the files found one by one.
*
*  Build Process:
*  --------------
*  devenv Project1.sln /rebuild debug
*
*  Required Files:
*  ---------------
*  Display.h, Display.cpp, Process.h, FileSystem.h,FileSystem.cpp,DirExplorerN.h,StringUtilities.h 
*
*  Maintenance History:
*  --------------------
*  ver 1.0 : 02 Feb 2019
*  - first release
*/

#include <string>
#include <vector>

class Display
{
public:
  //Constructor accepets:
  // Directory Path, File extention name, Application Path, Application command line options 
  //Display class will be able to use the Application to open all files 
  //with this File extention namein this Directory Path
  Display(std::string dirPath, std::string fileExt = "html", std::string appPath = "C:\\Program Files\\Mozilla Firefox\\firefox.exe", std::string cmdLine = "--new-window");

  //search all files with certain file extenson name
  void setFilesToDisplay(std::string dirPath, std::string fileExt);

  //set application path other than the default one. If the path is invalid, error will be throwed.
  void setAppPath(std::string appPath);

  //set command line parameters for application other than the default one.
  void setCmdLine(std::string cmdLine);

  //display all the files found one by one by creating child processes
  void DisplayFile();
private:
	std::string appPath;//path of application
	std::string cmdLine;//command line options for the application
	std::vector<std::string> filesToDisplay; //store all files to be displayed
};


