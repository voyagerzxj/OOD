#pragma once
///////////////////////////////////////////////////////////////////////
// Executive.h - contains Logger class and Executive class           //
//             - Logger class is used to put message into an ostream //
//             -  object. It can be used for logging/debugging.      //
//             - Executive class controls the whole file processing  //
//             -   procedure: parsing commandline, search files,     //
//             -   convert files, display files.                     // 
// ver 1.0                                                           //
// Xiaojun Zhang, CSE687 - Object Oriented Design, Spring 2019       //
/////////////////////////////////////////////////////////////////////// 

/*
*  Package Operations:
*  -------------------
*  Logger class is used to put message(content and title) into an ostream 
*         object. It can be used for logging/debugging. It can be turned on/off by the switch.
*  Executive class controls the whole file processing procedure: 
*         1.parsing commandline, get parameters like patterns/regexes, root dir.
*         2.sets parameters for the program to run: Application path, output directory, template file path, etc.
*         3.search files under root dir which matches patterns/regexes using DirExplorerN
*         4.convert all found files into (html) file and save into output dir using Convert class
*         5.display all html file under output by processes of browser app using Display class.
*
*  Build Process:
*  --------------
*  devenv Project1.sln /rebuild debug
*
*  Required Files:
*  ---------------
*  Executive.h, Executive.cpp, Convert.h, Convert.cpp, Display.h, Display.cpp, FileSystem.h, FileSystem.cpp, 
*  StringUtilities.h, CodeUtilities.h, DirExplorerN.h
*
*  Maintenance History:
*  --------------------
*  ver 1.0 : 05 Feb 2019
*  - first release
*/

#include <iostream>
#include <string>
#include <vector>
#include "../Utilities/CodeUtilities/CodeUtilities.h"

/////////////////////////////////////////////////////////
// helper Logger
class Logger {

public:
	//initialize the logger by output stream and log switch
	Logger(std::ostream& out = std::cout, bool logswitch=false);

	//generate a piece of info by titile and content, add to logger outputStream
	void generateLog(std::string contenttitle = "", std::string title = "");

	//set logger switch on/off by interactive in the console
	void setLoggerSwitch();

	//set logger switch on/off by bool value
	void setLoggerSwitch(bool loggerFlag);

private:
	//the switch controls whether the logging is on or off
	bool loggerSwitch;

	//decides where the logging info goes to
	std::ostream & outputStream;
};

/////////////////////////////////////////////////////////
// Executive
class Executive
{
public:
    //initialize by parsing the command line arguments using ProcessCmdLine class
	Executive(int argc, char** argv, bool logswitch );

	//finds all the files under certain dirctory root with certain pattern/regex 
	void findAllFiles();

	//convert all the files one by one according to Convert class
	void convertAllFiles();

	//display all resulting files one by one using Display class 
	void displayAllFiles();

	//set output directory
	void setOutputDir(std::string outputDir);

	//template file spec
	void setTemplateFileSpec(std::string templateFileSpec);

	//set the path of application(browser)
	void setAppPath(std::string appPath);

	//get the path of application(browser)
	std::string getAppPath();

	//get reference to the logger
	Logger& getLogger();

private:
	//store all the files to be converted
	std::vector<std::string> filesToProcess;
	
	//store output directory
	std::string outputDir;

	//store template file spec. 
	std::string templateFileSpec;
	
	//stores the application path which we will use to open files
	std::string appPath;

	//helper to record what happens
	Logger logger;

	//helper to parse the command line arguments
	Utilities::ProcessCmdLine pcl;
};


