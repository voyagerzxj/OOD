///////////////////////////////////////////////////////////////////////
// Executive.cpp - contains Logger class and Executive class         //
//             - Logger class is used to put message into an ostream //
//             -  object. It can be used for logging/debugging.      //
//             - Executive class controls the whole file processing  //
//             -   procedure: parsing commandline, search files,     //
//             -   convert files, display files.                     // 
// ver 1.0                                                           //
// Xiaojun Zhang, CSE687 - Object Oriented Design, Spring 2019       //
/////////////////////////////////////////////////////////////////////// 

#include "Executive.h"
#include "../Convert/Convert.h"
#include "../Display/Display.h"
#include "../FileSystem/FileSystem.h"
#include "../DirExplorer-Naive/DirExplorerN.h"
#include "../Utilities/StringUtilities/StringUtilities.h"
#include <iostream>
#include <conio.h>

using namespace Utilities;
using namespace FileSystem;

/////////////////////////////////////////////////////////
// helper Logger
//----< initialize the logger by output stream and log switch >-----------------------------------
Logger::Logger(std::ostream& out, bool logswitch)
:outputStream(out)
{
	
	this->loggerSwitch = logswitch;
}

//----< generate a piece of info by titile and content, add to logger outputStream >-----------------------------------
void Logger::generateLog(std::string content,std::string title)
{
	if (loggerSwitch)
	{
		if (title != "") {
			outputStream << "\n";
			Utilities::title(title, outputStream);
			outputStream << "\n";
		}
		if (content != "")outputStream << content << "\n";
	}
}

//----< set logger switch on/off by interactive in the console >-----------------------------------
void Logger::setLoggerSwitch()
{
   char answer;
   std::cout << "Do you want to use logger? (y/n)" << std::endl;
   std::cin >> answer;
   if (toupper(answer)) 
   {
	   loggerSwitch = true;
	   preface("Logger is on.\n");
   }
   else {
	   loggerSwitch = false;
	   preface("Logger is off.\n");
   }
}

//----< set logger switch on/off by bool value >-----------------------------------
void Logger::setLoggerSwitch(bool loggerFlag)
{
	if (loggerFlag)
	{
		loggerSwitch = true;
		preface("Logger is on.\n");
	}
	else {
		loggerSwitch = false;
		preface("Logger is off.\n");
	}
}




/////////////////////////////////////////////////////////
// Executive
//----< Use ProcessCmdLine to parse command line to construct Executive object >-----------------------------------
Executive::Executive(int argc, char** argv, bool logswitch)
	:pcl(argc, argv)
{
	logger.setLoggerSwitch(logswitch);
	logger.generateLog("", "Parsing Command Line"); 
	std::cout << "Command Line: "; //show cmd line
	pcl.showCmdLine();
	std::cout << std::endl;
	if (pcl.parseError()) //command line is not correct,fail
	{
		logger.generateLog("Parse Error!");
		pcl.usage();
		std::cout << "\n\n";
	}
	logger.generateLog("Parse Success!"); //success
}

//----< search files under root dir which matches patterns/regexes using DirExplorerN >-----------------------------------
void Executive::findAllFiles()
{
	if (pcl.parseError()) return; //parse error leads to no search
	DirExplorerN de(Path::getFullFileSpec(pcl.path()));
	if (pcl.hasOption('s')) //set resursion attribute
	{
		de.recurse();
		logger.generateLog("Recurse flag is on.");
	}
	for (auto patt : pcl.patterns()) //set patterns vector to store all patterns
	{
		de.addPattern(patt);
		logger.generateLog("Pattern found: " + patt);
	}
	for (auto regexpression : pcl.regexes()) //set regex vector to store all regexes
	{
		de.addRegex(regexpression);
		logger.generateLog("Regular Expression found: " + regexpression);
	}
	//Use DirExplorerN to find all files to be processed
	logger.generateLog("", "Searching Files");
	filesToProcess = de.getFilesToProcess(); // vector with files to be processed}
	if (filesToProcess.empty())
	{
		logger.generateLog("No File is found");
	}
	else
	{
		logger.generateLog("Files found:");
		for (auto f : filesToProcess) { logger.generateLog(f); }
	}
}

//----< set output directory >-----------------------------------
void Executive::setOutputDir(std::string outputDir)
{
	this->outputDir = outputDir;
}

//----< set template file spec >-----------------------------------
void Executive::setTemplateFileSpec(std::string templateFileSpec)
{
	this->templateFileSpec = templateFileSpec;
}

//----< get reference to the logger >-----------------------------------
Logger & Executive::getLogger()
{
	return logger;
}

//----< set the path of application(browser) >-----------------------------------
void Executive::setAppPath(std::string appPath)
{   //if application path is invalid, throw an error.
	if (!File::exists(appPath)) throw std::runtime_error("Not a valid application path ");
	this->appPath = appPath;
}

//----< get the path of application(browser)>-----------------------------------
std::string Executive::getAppPath()
{
	return appPath;
}

//----< convert all the files found one by one according to Convert class >-----------------------------------
void Executive::convertAllFiles()
{
	if (filesToProcess.empty()) return;
	logger.generateLog("","Convert All Files");
	for (auto file : filesToProcess) {//process each file into html file
		logger.generateLog("Reading "+file);
		Convert converter(file, outputDir, templateFileSpec);
		logger.generateLog("Converting " + file);
		converter.doConversion();
		converter.createHTMLfile(); 
		logger.generateLog("HTML file generated.\n");
	}
}

//----< display all resulting files one by one using Display class >-----------------------------------
void Executive::displayAllFiles()
{
	logger.generateLog ("","Display All converted HTML files one by one!!!");
	std::cout << "  Will start the browser for each converted file and each time wait for termination.";
	std::cout << "\n  You need to kill each window (upper right button) to continue.";
	std::cout << "\n  Press key to start";
	_getche();
	Display displayer(outputDir, "html", appPath, "--new-window");
	displayer.DisplayFile();
	logger.generateLog("All Files are viewed.");
	std::cout.flush();
	char ch;
	std::cin.read(&ch, 1);
	return;
}

//----< Main function >-----------------------------------
//Execution starts from here.
int main(int argc, char *argv[])
{
	//Construct, parsing, logging
	Executive sourceCodePublisher(argc, argv,true);
	Logger& logger = sourceCodePublisher.getLogger();
    //set variables for execution
	sourceCodePublisher.setOutputDir (Path::getFullFileSpec("../ConvertedWebpages/")); //output directory
	sourceCodePublisher.setTemplateFileSpec ( Path::getFullFileSpec("../HTMLtemplate.html")); //template HTML file path
	try 
	{	
		sourceCodePublisher.setAppPath ( "C:\\Program Files\\Mozilla Firefox\\firefox.exe"); //browser path
	}
	catch(std::exception& ex ){
		(ex);
		std::cout << "Not a valid application path." << std::endl;
		logger.generateLog("Application path is not valid.");
		return -1;
	}
	logger.generateLog("Application path: "+sourceCodePublisher.getAppPath());
    //start processing
	sourceCodePublisher.findAllFiles(); //search all the files matches patts/regexes under root dir
	sourceCodePublisher.convertAllFiles(); //convert all the files into html files
	sourceCodePublisher.displayAllFiles(); // display all the html files
}