///////////////////////////////////////////////////////////////////////
// Convert.cpp - class used to load a source file for processing,    //
//             - convert the file into a webpage fragment,           //
//             - and convert the html fragment into a valid html     //
//             - document.                                           //
// ver 1.0                                                           //
// Xiaojun Zhang, CSE687 - Object Oriented Design, Spring 2019       //
/////////////////////////////////////////////////////////////////////// 

#include "Convert.h"
#include <iostream>
#include <string>
#include "../FileSystem/FileSystem.h"
#include "../Utilities/StringUtilities/StringUtilities.h"

using namespace Utilities;
using namespace FileSystem;

//----< Constructor sets output directory, source file path, html template file path and read in the content of source code file >-----------------------------------
Convert::Convert(std::string sourceFileSpec, std::string outputDir, std::string templateFileSpec)
{
	if (!(FileSystem::File::exists(sourceFileSpec)))//if source file doesn't exist, error
		throw std::runtime_error("Source file does not exist.");
	if (!(FileSystem::File::exists(templateFileSpec)))//if template file doesn't exist, error
		throw std::runtime_error("Template file does not exist.");
	if (!FileSystem::Directory::exists(outputDir)) // it's always important to verify if the directory already exists
		FileSystem::Directory::create(outputDir);
	this->outputDir = outputDir; 
	this->sourceFileSpec = sourceFileSpec; 
	this->templateFileSpec = templateFileSpec; 
	readInFile();                     //read in contents of source file
	setSentinelMap();                 //set sentinal map for replacement sentinels in template file
}

//----< helper function to replace all occurances of toSearch substring in data string with replaceStr string >-----------------------------------
void Convert::findAndReplaceAll(std::string & data, std::string toSearch, std::string replaceStr)
{
	// Get the first occurrence
	size_t pos = data.find(toSearch);

	// Repeat till end is reached
	while (pos != std::string::npos)
	{
		// Replace this occurrence of Sub String
		data.replace(pos, toSearch.size(), replaceStr);
		// Get the next occurrence from the current position
		pos = data.find(toSearch, pos + replaceStr.size());
	}
}

//----<read in the content of source code file, store into sourceFileContent >-----------------------------------
void Convert::readInFile()
{
	File sourceCodeFile(sourceFileSpec);
	sourceCodeFile.open(File::in);
	if (sourceCodeFile.isGood())
	{
		sourceFileContent = sourceCodeFile.readAll(true); //read all contents at once
	}
	sourceCodeFile.close();
}

//----<helper function to replace all angled brackets with escaped characters>-----------------------------------
void Convert::replaceBrackets(std::string &sourceCodeContent) 
{
	findAndReplaceAll(sourceCodeContent, "<", "&lt;");
	findAndReplaceAll(sourceCodeContent, ">", "&gt;");
}

//----<helper function to add pre tags at both ends of string>-----------------------------------
void Convert::addPreTags(std::string& sourceCodeContent) 
{
	sourceCodeContent =  "<pre>\n" + sourceCodeContent + "</pre>";
}

//----< set sentinel map. It is extensible in the future. >-----------------------------------
void Convert::setSentinelMap() 
{
	sentinelMap["@title"] = &sourceFileSpec;
	sentinelMap["@code"] = &sourceFileContent;
}

//----<replace the sentinels in the input string with certain string>-----------------------------------
std::string Convert::replaceSentinel(std::string& inputstring)
{
	for (auto& kv : sentinelMap) {
		findAndReplaceAll(inputstring, kv.first, *kv.second);
	}
	return inputstring;
}

//----<translate original content of source file into html segment>-----------------------------------
void Convert::doConversion()
{    
	replaceBrackets(sourceFileContent);
	addPreTags(sourceFileContent);
}

//----<creates HTML file >-----------------------------------
void Convert::createHTMLfile() {   
	//set and open template file
	FileSystem::File templateFile(templateFileSpec); 
	templateFile.open(File::in, File::text); 

	//set and open source code file
	std::string HTMLFileName = Path::getName(sourceFileSpec) + ".html";  //add .html extension to original file name
	std::string HTMLFilePath = Path::fileSpec(outputDir, HTMLFileName);
	FileSystem::File outputFile(HTMLFilePath);
	outputFile.open(File::out, File::text);

	//read in template file  a line at a time, replace sentinels with certain strings, output the result line into outputfile
	while (outputFile.isGood() && templateFile.isGood())
	{
		std::string temp = templateFile.getLine();
		outputFile.putLine(replaceSentinel(temp));
	}

	//close files
	templateFile.close();
	outputFile.close();
}

void Convert::showSourceFileContent()
{
	std::cout << sourceFileContent << std::endl;
}

//----< test stub >--------------------------------------------------------
#ifdef TEST_CONVERT
int main() {
	//I will save the output file in TestWebPages
	Convert converter("../Proj1Helper.cpp","../TestWebPages");

	//test on real cpp file
	std::cout << "Convert Proj1Helper.cpp\n" << std::endl;
	converter.doConversion();
	//show doConversion result
	std::cout << "!!!The result code after doConversion is:   !!!" << std::endl;
	converter.showSourceFileContent();

	std::cout << "\n/////////////////////////////////////////////////////\n" << std::endl;

    //show result html file content
	converter.createHTMLfile();
	FileSystem::File outputFile("../TestWebPages/Proj1Helper.cpp.html");
	outputFile.open(File::in, File::text);
	std::string fileContent = outputFile.readAll(true);
	std::cout << "!!! The result html file content is: !!!" << std::endl;
	std::cout << fileContent << std::endl;
	outputFile.close();

}
#endif
