#pragma once
///////////////////////////////////////////////////////////////////////
// Convert.h - class used to load a source file for processing,      //
//             - convert the file into a webpage fragment,           //
//             - and convert the html fragment into a valid html     //
//             - document.                                           //
// ver 1.0                                                           //
// Xiaojun Zhang, CSE687 - Object Oriented Design, Spring 2019       //
/////////////////////////////////////////////////////////////////////// 

/*
*  Package Operations:
*  -------------------
*  This package provides a class, Convert, used to convert a source file by 
*  replacing it escaping characters, add tags; then insert that piece of code into a template file, 
*  and save the result into certain directory.
*  It uses FileSystem class to manipulate creation of files/dirs.
*
*  Build Process:
*  --------------
*  devenv Project1.sln /rebuild debug
*
*  Required Files:
*  ---------------
*  Convert.h, Convert.cpp, Process.h, FileSystem.h, FileSystem.cpp, StringUtilities.h
*
*  Maintenance History:
*  --------------------
*  ver 1.0 : 02 Feb 2019
*  - first release
*/
#include <string>
#include<map>

class Convert {
public:
	//Constructor takes source file spec, output directory, template file spec, and read in the content of source file
	Convert( std::string sourceFileSpec, std::string outputDir = "../ConvertedWebpages/",std::string templateFileSpec = "../HTMLtemplate.html");
	
	//Convert the original source file code into a webpage fragment surrounded by pre tags
	void doConversion();
	
	//insert the webpage fragment into the template file to create final HTML pagge
	void createHTMLfile();
	
	//show original/converted source file content (saved in the Convert object)
	void showSourceFileContent();
		
private:
	//helper function to replace all occurances of toSearch substring in data string with replaceStr string
    void findAndReplaceAll(std::string & data, std::string toSearch, std::string replaceStr);

	//read in the content of source file
	void readInFile();

	//set sentinel map, mapping sentinels to replacing strings.
    void setSentinelMap();

	//replace angled brackets with escape chars
	void replaceBrackets(std::string& sourceCodeContent);

	//add pre tags at both ends of the code
	void addPreTags(std::string& sourceCodeContent);

	//there are some sentinels in the template file, use this function to replace these sentinel with certain string
	std::string replaceSentinel(std::string &inputstring);

	//Directory for output files
	std::string outputDir;

	//Full source file spec (the source code file to read from)
	std::string sourceFileSpec;

	//Full template file spec (the html template file to read from, contains sentinels, in order to build HTML file)
	std::string templateFileSpec;

	//store the original/converted source code file
	std::string sourceFileContent;

	//The map is used to translate sentinels to replacement string. 
	//The key is sentinels in HTML template file. The value is the string* I want to use to replace the sentinel.
	std::map<std::string, std::string *> sentinelMap;
};