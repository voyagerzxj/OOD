#pragma once
///////////////////////////////////////////////////////////////////////////////
// InheritanceDemo.h - Demonstrates memory layout of Inheritance Hierarchies //
//                                                                           //
// Jim Fawcett, CSE687 - Object Oriented Design - demonstration              //
///////////////////////////////////////////////////////////////////////////////

#include <string>

/////////////////////////////////////////////////////////////////////
// C++ interface

struct IInheritance
{
  virtual ~IInheritance() {}
  virtual void operationA(const std::string& str) = 0;
  virtual std::string operationB() = 0;
};
/////////////////////////////////////////////////////////////////////
// abstract base class

class Base : public IInheritance  // abstract since operationB() isn't defined
{
public:
  Base(const std::string& msg);
  virtual void operationA(const std::string& str);
protected:
  std::string B_msg;          // instance member
  static std::string S_msg;   // static member
};

std::string Base::S_msg;      // define static value

/////////////////////////////////////////////////////////////////////
// Concrete derived classes

class Derived1 : public Base
{
public:
  Derived1(const std::string& _msg);
  virtual std::string operationB();
private:
  std::string D1_msg;
};

class Derived2 : public Base
{
public:
  Derived2();
  virtual std::string operationB();
};