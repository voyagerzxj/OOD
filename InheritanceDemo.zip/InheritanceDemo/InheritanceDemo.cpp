/////////////////////////////////////////////////////////////////////////////////
// InheritanceDemo.cpp - Demonstrates memory layout of Inheritance Hierarchies //
//                                                                             //
// Jim Fawcett, CSE687 - Object Oriented Design - demonstration                //
/////////////////////////////////////////////////////////////////////////////////


#include "InheritanceDemo.h"
#include "..\Utilities\Utilities.h"
#include <iostream>

using namespace Utilities;

Base::Base(const std::string& msg)
{
  B_msg = msg;
  std::cout << "\n  location of Base:\t\t";     DisplayLocation(*this);
  std::cout << "\n  location of Base::B_msg\t"; DisplayLocation(B_msg);
  std::cout << "\n  location of Base::S_msg\t"; DisplayLocation(S_msg);
  std::cout << "\n";
}

void Base::operationA(const std::string& str)
{
  std::cout << "\n  operationA received std::string \"" << str << "\"";
}

Derived1::Derived1(const std::string& msg) : Base("string for Base")
{
  std::cout << "\n  location of Derived1\t\t";       DisplayLocation(*this);
  std::cout << "\n  location of Derived1::B_msg\t";  DisplayLocation(B_msg);
  std::cout << "\n  location of Derived1::D1_msg\t"; DisplayLocation(D1_msg);
  std::cout << "\n  location of Derived1::S_msg\t";  DisplayLocation(S_msg);
  std::cout << "\n";
  std::cout << "\n  Derived1 ctor received std::string \"" << msg << "\"";
  D1_msg = msg;
}

std::string Derived1::operationB()
{
  return D1_msg;
}

Derived2::Derived2() : Base("another string for Base")
{
  std::cout << "\n  location of Derived1\t\t";       DisplayLocation(*this);
  std::cout << "\n  location of Derived1::B_msg\t";  DisplayLocation(B_msg);
  std::cout << "\n  location of Derived1::S_msg\t";  DisplayLocation(S_msg);
  std::cout << "\n";
}

std::string Derived2::operationB()
{
  return "Derived2 doesn't have a message";
}

//----< object factory method >--------------------------------------

using Util = StringHelper;

IInheritance* factory(size_t id)
{
  switch (id)
  {
  case 1:
    Util::title("Creating instance of Derived1");
    return new Derived1("message for d1");
    break;
  case 2:
    Util::title("Creating instance of Derived2");
    return new Derived2();
    break;
  default:
    Util::title("\n  Error - no such id");
    return nullptr;
  }
}
//----< test stub >--------------------------------------------------

int main()
{
  Util::Title("Inheritance Demo");
  putline();
  IInheritance* pII = factory(1);
  pII->operationA("string for d1");
  std::cout << "\n  " << pII->operationB();
  std::cout << "\n  size of d1 = " << sizeof(*dynamic_cast<Derived1*>(pII));
  delete pII;
  putline();

  pII = factory(2);
  pII->operationA("string for d2");
  std::cout << "\n  " << pII->operationB();
  delete pII;

  pII = factory(0);
  std::cout << "\n\n";
  
}