/////////////////////////////////////////////////////////////////////////////
// exPerf.cpp - demonstrate performance of Standard C++ exceptions
//
// Jim Fawcett, CSE691 - SW Modeling & Analysis, Fall 2000
/////////////////////////////////////////////////////////////////////////////
// Platform: Dell XPS1000, Windows 2000 Professional, SP1

#include <windows.h>
#include <exception>
#include <iostream>
#include "timer.h"

/////////////////////////////////////////////////////////////////////////////
// test with exceptions

void testWexcept(bool condition) {

  static bool first = true;
  if(first) {
    std::cout << "\n  using exceptions";
    first = false;
  }
  try {
    if(condition)
      throw std::exception();
  }
  catch(std::exception &e) { std::cout << e.what() << std::endl; }
};

/////////////////////////////////////////////////////////////////////////////
// test without exceptions

void testWOexcept(bool) { 

  static bool first = true;
  if(first) {
    std::cout << "\n  not using exceptions";
    first = false;
  }
}

//

/////////////////////////////////////////////////////////////////////////////
// function to time function calls

template<class arg> 
clock_t timeFunction(void(*pFunc)(arg a), arg a, int N) {

  timer t;
  t.start();
  int i;
  for(i=0; i<N; i++)
    pFunc(a);
  t.stop();

  std::cout << "\n  type of argument is " << typeid(a).name();

  std::cout << "\n  time to call function " << N << " times = " 
            << t.elapsed() << " milliseconds" << std::endl;
  
  return t.elapsed();
}

/////////////////////////////////////////////////////////////////////////////
// test stub

void main() {

  std::cout << "\n  Demo Performance - with and without exceptions "
       << "\n =================================================\n";

  const int N = 5000000;

  timeFunction<bool>(testWexcept, false, N);
 
  timeFunction<bool>(testWOexcept, false, N);

  std::cout << "\n\n";
}

