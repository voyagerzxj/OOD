///////////////////////////////////////////////////////////////////////
// DemoProcCmdLine.cpp - How to pass array of strings to ProcCmdLine //
//                                                                   //
// Jim Fawcett, CSE687 - Object Oriented Design, Project #4 Help     //
///////////////////////////////////////////////////////////////////////

#include "../Utilities/CodeUtilities/CodeUtilities.h"
#include <iostream>
#include <string>
#include <array>
#include <vector>

using namespace Utilities;

int main()
{
  std::cout << "\n  Demonstrate passing array of strings to ProcessCmdLine";
  std::cout << "\n ========================================================\n";

  // first technique : everything created in static memory.
  // - Start with native array of std::strings.
  // - Construct array of pointers to first character of each string in array.
  //   That array resides in static memory.
  // - Use to construct ProcessCmdLine instance and invoke it's showCmdLine() method.

  const size_t MAX = 5;
  std::string strArray[MAX]
  { 
    "DemoProcCmdLine.exe", // name of execution image
    "..",                  // path
    "*.h",                 // first pattern
    "*.cpp",               // second pattern
    "*.cs"                 // third pattern
  };

  char* argv[MAX]
  { 
    &strArray[0][0], &strArray[1][0], &strArray[2][0], &strArray[3][0], &strArray[4][0] 
  };
  Utilities::ProcessCmdLine pcl(MAX, argv);
  
  std::cout << "\n  First method\n  ";
  pcl.showCmdLine();
  std::cout << "\n";

  // Second technique : everything created in static memory.
  // - Start with native array of std::strings.
  // - Construct vector of pointers to first character of each string in array.
  //   That array resides in static memory.
  // - Use to construct ProcessCmdLine instance and invoke it's showCmdLine() method.

  std::array<const char*, MAX> arrayPtrChar
  {
    "DemoProcCmdLine.exe", // name of execution image
    "..",                  // path
    "*.h",                 // first pattern
    "*.cpp",               // second pattern
    "*.cs"                 // third pattern
  };

  std::vector<const char*> vecLiteralStr(arrayPtrChar.cbegin(), arrayPtrChar.cend());
  char** ptrVecContents = const_cast<char**>(&vecLiteralStr[0]);

  ProcessCmdLine pcl3(MAX, ptrVecContents);
  std::cout << "\n  Second method:\n  ";
  pcl3.showCmdLine();
  std::cout << "\n";

  // Third technique - the hard way, attempted by a student
  // - Start with std::array of std::strings.
  // - Construct native array of pointers to char on heap.
  // - Fill each element of that array with pointer to array of chars sized to fit the associated string.
  // - Fill each array of chars with contents of associated string.
  // - Use to construct ProcessCmdLine instance and invoke it's showCmdLine() method.
  // - Delete each string pointer.
  // - Delete array pointer.

  char** ptrLiteralStrArray = new char*[MAX];
  for (size_t i=0; i<MAX; ++i)
  {
    ptrLiteralStrArray[i] = new char[strlen(arrayPtrChar[i]) + 1];
    memcpy(ptrLiteralStrArray[i], arrayPtrChar[i], strlen(arrayPtrChar[i]) + 1);
  }

  ProcessCmdLine pcl2(MAX, ptrLiteralStrArray);
  std::cout << "\n  Third method:\n  ";
  pcl2.showCmdLine();

  // have to clean up all that storage

  for (size_t i = 0; i < MAX; ++i)
  {
    delete[] ptrLiteralStrArray[i];
  }
  delete ptrLiteralStrArray;
  std::cout << "\n";

  std::cout << "\n\n";
}

