///////////////////////////////////////////////////////////////
//  IterateOverArray.cpp  - demonstrate stream iterators     //
//                ----------------------------               //
//                                                           //
//  Jim Fawcett, 4/4/98                                      //
///////////////////////////////////////////////////////////////

#include <iostream>
#include <algorithm>
#include <array>
 
int main() {
  std::cout << "\n  Demonstrate array iterations";
  std::cout << "\n ==============================\n";

  std::cout << "\n  indexing sorted native array";
  std::cout << "\n ------------------------------";
  int array[] = { 23, 5, -10, 0, 0, 321, 1, 2, 99, 30 };
  int elements = sizeof(array) / sizeof(array[0]); 
  std::sort(array, array + elements);
  std::cout << "\n  ";
  for (int i = 0; i < elements; ++i) 
     std::cout << array[i] << ' ';
  std::cout << "\n";

  std::cout << "\n  iterating over std::array";
  std::cout << "\n ----------------------------";
  std::array<int,10> arrayObj = { 23, 5, -10, 0, 0, 321, 1, 2, 99, 30 };
  std::array<int, 10>::iterator biter = arrayObj.begin();
  std::array<int, 10>::iterator eiter = arrayObj.end();
  std::cout << "\n  ";
  for (std::array<int, 10>::iterator iter = biter; iter != eiter; ++iter)
    std::cout << *iter << ' ';
  std::cout << "\n\n";
}
