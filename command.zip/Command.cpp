///////////////////////////////////////////////////////////////
//  command.cpp - test command and invoker classes           //
//  ver 1.0       This code acts as the client of the        //
//                invoker and abstract command classes.      //
//                                                           //
//  Lanuage:      Visual C++, ver 6.0                        //
//  Platform:     Micron Dual Pentium Pro 200, Win NT 4.0    //
//  Application:  CSE791 - Design Patterns Example           //
//  Author:       Jim Fawcett, Instructor                    //
//                CST 2-187, (315) 443-3948                  //
//                fawcett@ecs.syr.edu                        //
///////////////////////////////////////////////////////////////

#include <string>
#include <iostream>
#include "command.h"
using namespace std;

/// NOTICE!!!! //////////////////////////////////////////////////
//  Derived classes below could be created long after library  //
//  invoker and abstract command classes were defined.  Yet    //
//  invoker can cause the execution of execute() functions     //
//  provided here in response to any one of library's internal //
//  events.  This comes about through power of polymorphism!   //
/////////////////////////////////////////////////////////////////

class concreteCommand1 : public command {

public:
  concreteCommand1(string s) : cc1(s) { }
  void execute(invoker::events event);

private:
  string cc1;
};


class concreteCommand2 : public command {

public:
  concreteCommand2(string s) : cc2(s) { }
  void execute(invoker::events event);

private:
  string cc2;
};


//

///////////////////////////////////////////////////////////////
//  this function represents client #1 processing in         //
//  response to one of the invoker::events                   //
///////////////////////////////////////////////////////////////

void concreteCommand1::execute(invoker::events event) {

  switch(event) {
    case invoker::firstEv : 
      cout << "\n  " << cc1 << " has been notified of  first event"; break;
    case invoker::secondEv : 
      cout << "\n  " << cc1 << " has been notified of second event"; break;
    case invoker::thirdEv : 
      cout << "\n  " << cc1 << " has been notified of  third event"; break;
    default:
      cout << "\n  " << cc1 << " has been notified of an unknown event";
  }
}

///////////////////////////////////////////////////////////////
//  this function represents client #2 processing in         //
//  response to one of the invoker::events                   //
///////////////////////////////////////////////////////////////

void concreteCommand2::execute(invoker::events event) {

  switch(event) {
    case invoker::firstEv : 
      cout << "\n  " << cc2 << " has been notified of  first event"; break;
    case invoker::secondEv : 
      cout << "\n  " << cc2 << " has been notified of second event"; break;
    case invoker::thirdEv : 
      cout << "\n  " << cc2 << " has been notified of  third event"; break;
    default:
      cout << "\n  " << cc2 << " has been notified of an unknown event";
  }
}

//

#ifdef TEST_COMMAND

int main() {

  std::cout << "\n  Command Pattern Demonstration";
  std::cout << "\n ===============================\n";

///////////////////////////////////////////////////////////////
//  create concrete commands, passing them any information   //
//  needed for their execute functions                       //
///////////////////////////////////////////////////////////////

  concreteCommand1 comm1("client #1");
  concreteCommand2 comm2("client #2");

///////////////////////////////////////////////////////////////
//  any client can register interest in library events       //
///////////////////////////////////////////////////////////////

  invoker inv;
  inv.Register(&comm1);   // client #1
  inv.Register(&comm2);   // client #2

///////////////////////////////////////////////////////////////
//  use the library facilities                               //
///////////////////////////////////////////////////////////////

  inv.doEvents();         // clients get notified here

  cout << endl << endl;
  return 0;
}

#endif
