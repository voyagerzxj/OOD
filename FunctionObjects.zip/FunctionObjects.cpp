/////////////////////////////////////////////////////////////////////////
// FunctionObjects.cpp - demonstrate function object declar and invoc. //
//                                                                     //
// Jim Fawcett, CSE687 - Object Oriented Design, Summer 2017           //
/////////////////////////////////////////////////////////////////////////

#include "FunctionObjects.h"
#include "../Utilities/Utilities.h"
#include <iostream>

void testFunction(size_t lineNo, const std::string& str)
{
  std::cout << "\n  line number " << lineNo << " : calling " << __FUNCTION__;
  std::cout << " with message \"" << str << "\"";
}

void FunctorExample::operator()(const std::string& arg)
{
  testFunction(lineNo_, "functor demo");
  std::cout << "\n    by calling " << __FUNCTION__ << " with argument \"" << arg << "\"";
}

Cosmetic cosmetic;

int main()
{
  putTitle("Demonstrate Function Objects", '=');
  putLine();

  testFunction(__LINE__, "function demo");
  putLine();

  fPtr = &testFunction;
  fPtr(__LINE__, "function pointer demo");
  putLine();

  FPtr tdPtr = &testFunction;
  tdPtr(__LINE__, "function pointer type demo");
  putLine();

  AFPtr aPtr = &testFunction;
  aPtr(__LINE__, "function pointer alias demo");
  putLine();

  FunctorExample fe(__LINE__ + 1);
  fe("additional message");
  putLine();

  stdFunc = [](const std::string& str) 
  { 
    testFunction(__LINE__ + 1, str); std::cout << "\n    by calling \"" << __FUNCTION__; 
  };
  stdFunc("lambda demo");
  putLine();
}