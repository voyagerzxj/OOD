///////////////////////////////////////////////////////////////
// constraints.cpp - compile time type tests                 //
//                                                           //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2005 //
///////////////////////////////////////////////////////////////

#include <iostream>
#include "constraints.h"

/////////////////////////////////////////////////
// test classes

class B {};
class D : public B
{
public:
  D() {} 
  B* clone() { return new D; } 
};

struct PODS { int x; char y; double d; };

struct Non_PODS
{ 
  Non_PODS() : x(1) {}   // has non-default ctor
  int x; char y; double d; 
};

//
void main()
{
  /////////////////////////////////////////
  // test Is_Derived

  Is_Derived(D,B);       // ok
  Is_Derived<D,B>();     // ok
#ifdef FAIL1
  Is_Derived(B,D);       // compilation fails
#endif

  /////////////////////////////////////////
  // test Is_Clonable

  Is_Clonable(D);        // ok
#ifdef FAIL2
  Is_Clonable(B);        // compilation fails
#endif

  /////////////////////////////////////////
  // test Is_Pointer

  Is_Pointer(int*);      // ok
#ifdef FAIL3
  Is_Pointer(int);       // compilation fails
#endif

  /////////////////////////////////////////
  // test Is_POD

  Is_POD(double);       // ok
  Is_POD(int);          // ok
  Is_POD(B);            // ok
#ifdef FAIL4
  Is_POD(D);            // compilation fails
  Is_POD(Non_PODS);     // compilation fails
#endif

  /////////////////////////////////////////
  // test Is_Same_Size

  Is_Same_Size(int,int);
  Is_Same_Size(int,long);
  Is_Same_Size(int*,int);
#ifdef FAIL5
  Is_Same_Size(short,int);
  Is_Same_Size(float,double);
#endif

  std::cout << "\n  Run-Time Checks:\n  ";
  std::cout << is_same_size(float,float) << " ";
  std::cout << is_same_size(float,double) << "\n\n";
}
