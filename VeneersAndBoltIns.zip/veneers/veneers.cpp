///////////////////////////////////////////////////////////////
// veneers.cpp - Add behavior without changing size          //
//                                                           //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2005 //
///////////////////////////////////////////////////////////////

#include <windows.h>
#include <process.h>
#include "veneers.h"

/////////////////////////////////////////////////
// Test stub

#ifdef TEST_VENEERS

#include <iostream>

///////////////////////////////////////////////////
// this global object causes newlines to be emitted
// after local objects are destroyed and main
// completes

struct TerminalNewLine
{
  ~TerminalNewLine() { std::cout << "\n\n"; }
} global;

void main()
{
  ///////////////////////////////////////////////
  // test POD_veener

  std::cout << "\n  Testing POD_veeners that wrap Win32 HANDLES";
  std::cout << "\n =============================================\n";

  std::cout << "\n  Construct event and wait on it for 2 seconds";
  Event event;
  std::cout << "\n  waiting for 2 seconds";
  WaitForSingleObject(event,2000);
  std::cout << "\n  returned from wait on event" << "\n";

  std::cout << "\n  Construct mutex, shared with thread,";
  std::cout << " and wait on it until released by thread";
  Mutex mtx;
  Thread thd;
  Sleep(50);  // give thread time to start and acquire mutex
  WaitForSingleObject(mtx,INFINITE);  // blocking until thread releases mutex
  ReleaseMutex(mtx);                  // release immediately once acquired
  std::cout << "\n  returned from wait on mutex\n";

  std::cout << "\n  wait for thread to terminate";
  Thread wThd;
  WaitForSingleObject(wThd,INFINITE);
  std::cout << "\n  returned from wait on thread\n";
}

#endif
