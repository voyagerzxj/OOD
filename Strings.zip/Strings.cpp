/////////////////////////////////////////////////////////////////
// Strings.cpp - string utility functions                      //
//                                                             //
// Jim Fawcett, CSE687 - Object Oriented Design, Summer 2017   //
/////////////////////////////////////////////////////////////////

#include "Strings.h"
#include "../Utilities/Utilities.h"
#include <locale>
#include <iostream>

void showString(const std::string& str)
{
  std::cout << "\n  \"" << str << "\"";
}

void showString(const std::wstring& str)
{
  std::wcout << L"\n  L\"" << str << L"\"";
}

#ifdef TEST_STRINGS

using namespace Utilities;

int main()
{
  putTitle("Demonstrating string operations", '=');
  putLine();

  putTitle("trimming std::string");
  std::string test1 = " first test ";
  showString(test1);
  showString(trim(test1));
  putLine();

  putTitle("trimming std::wstring");
  std::wstring test2 = L" second test ";
  showString(test2);
  showString(trim(test2));
  putLine();

  putTitle("splitting std::string using default delimiter \',\'");
  std::string testa = " test1, test2, test3 ";
  showString(testa);
  std::vector<std::string> splits = split(testa);
  showSplits(splits);

  putTitle("splitting std::string with delimiter \'@\'");
  testa = " test1 @ test2 @ test3 ";
  showString(testa);
  splits = split(testa, '@');
  showSplits(splits);

  putTitle("splitting std::wstring with delimiter \'&\'");
  std::wstring testb = L" test1 & test2 & test3 ";
  showString(testb);
  std::vector<std::wstring> wsplits = split(testb, wchar_t('&'));
  showSplits(wsplits);

  std::cout << "\n\n";
}

#endif
