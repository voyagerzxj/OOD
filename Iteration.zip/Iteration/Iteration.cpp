///////////////////////////////////////////////////////////////////////////
// Iteration.cpp - demo forward and reverse iteration in STL containers  //
//                                                                       //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2019             //
///////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <deque>

/*-- display helpers --*/

auto putline = [](const std::string& msg = "") 
{ 
  std::cout << "\n  " << msg; 
};

auto title = [](const std::string& theTitle)
{
  std::cout << "\n  " << theTitle;
  std::cout << "\n " << std::string(theTitle.size() + 2, '-');
};

/*-- forward iteration for all sequence containers --*/

template<typename C>
void forwardIteration(const C& cont)
{
  //using Iter = typename C::iterator;  // use this if the input is not const
  using CIter = typename C::const_iterator;

  std::cout << "\n  ";
  for (CIter iter = cont.begin(); iter != cont.end(); iter++)
  {
    if (iter != --cont.end())
      std::cout << *iter << ", ";
    else
      std::cout << *iter;
  }
}

/*-- reverse iteration for all sequence containers --*/

template<typename C>
void reverseIteration(const C& cont)
{
  //using Iter = typename C::reverse_iterator;  // use this if the input is not const
  using CIter = typename C::const_reverse_iterator;

  std::cout << "\n  ";
  for (CIter iter = cont.rbegin(); iter != cont.rend(); iter++)
  {
    if (iter != --cont.rend())
      std::cout << *iter << ", ";
    else
      std::cout << *iter;
  }
}

int main()
{
  title("Demonstrating forward and reverse iteration");
  putline();

  putline("using std::deque<int>");
  std::deque<int> dq{ 1, 2, 3, 4 };
  forwardIteration(dq);
  reverseIteration(dq);
  putline();

  putline("using std::vector<double>");
  std::vector<double> vc{ 1, 1.5, 2, 2.5 };
  forwardIteration(vc);
  reverseIteration(vc);

  putline("\n  using std::list<std::string>");
  std::list<std::string> ls{ "one", "two", "three", "four" };
  forwardIteration(ls);
  reverseIteration(ls);
  
  putline("\n  using std::string");
  std::string str = "Hello CSE687 World";
  forwardIteration(str);
  reverseIteration(str);

  std::cout << "\n\n";
}