﻿/////////////////////////////////////////////////////////////////////
// GUI_Test.cs - demonstrate running a test at WPF App startup     //
//                                                                 //
// Jim Fawcett, CSE681-Software Modeling and Analysis, Fall 2017   //
/////////////////////////////////////////////////////////////////////
/*
 *  - Look at App.xaml.cs to see how bool test() is run at startup 
 *  - If started from a run.bat with a Developer's Command Prompt
 *    running as administrator, the WPF app will run as Administrator too.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Security.Principal;  // needed for IsAdministrator()

namespace GUI_Test
{
  ///////////////////////////////////////////////////////////////////
  // Demonstrate running test on startup

  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    public bool test()
    {
      int count = 0;
      Console.Write("\n  my command line is:");
      foreach(string arg in Environment.GetCommandLineArgs())
      {
        Console.Write("\n    arg#{0} = {1}", ++count, arg);
      }
      Console.Write("\n  running as administrator: {0}", IsAdministrator());
      Console.Write("\n  pretending to test Req #3");
      Console.Write("\n  pretending to test Req #4");
      Console.Write("\n  yada yada yada");
      Console.Write("\n");
      return true;
    }

    public bool IsAdministrator()
    {
      // https://stackoverflow.com/questions/11660184/c-sharp-check-if-run-as-administrator
      var identity = WindowsIdentity.GetCurrent();
      var principle = new WindowsPrincipal(identity);
      return principle.IsInRole(WindowsBuiltInRole.Administrator);
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      bool result = test();
      if (result == true)
        status.Text = "test passed";
      else
        status.Text = "test failed";
    }
  }
}
