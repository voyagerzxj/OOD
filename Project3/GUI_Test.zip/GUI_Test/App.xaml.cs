﻿/////////////////////////////////////////////////////////////////////
// App.xaml.cs - demonstrate running a test at WPF App startup     //
//                                                                 //
// Jim Fawcett, CSE681-Software Modeling and Analysis, Fall 2017   //
/////////////////////////////////////////////////////////////////////
/*
 *  - This file shows how bool test() is run at startup 
 *  - If GUI_Test.exe is started from a run.bat with a Developer's Command Prompt, 
 *    running as administrator, the WPF app will run as Administrator too.
 */
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace GUI_Test
{
  public partial class App : Application
  {
    //----< called as application starts up >------------------------

    private void Application_Startup(object sender, StartupEventArgs e)
    {
      GUI_Test.MainWindow mwin = new GUI_Test.MainWindow();
      ////////////////////////////////////////////////////
      // uncomment mwin.test to run test at startup

      if (e.Args.Length >= 1)
      {
        if (e.Args[0] == "test")
        {
          //bool result = mwin.test();
          Console.Write("\n  command line test passed");
        }
      }
    }
  }
}
