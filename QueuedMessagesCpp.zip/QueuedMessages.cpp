/////////////////////////////////////////////////////////////////
// QueuedMessages.cpp - communication between threads using a  //
//                      blockingQueue                          //
//                                                             //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2012   //
/////////////////////////////////////////////////////////////////

#include <string>
#include <iostream>
#include <sstream>
#include "BlockingQueue.h"
#include "Threads.h"
#include "locks.h"

template <typename T>
std::string convert(T t)
{
  std::ostringstream temp;
  temp << t;
  return temp.str();
}

class ChildThreadProc : public Thread_Processing<ChildThreadProc>
{
public:
  ChildThreadProc(BQueue<std::string>& Q) : Q_(Q) {}
  void run()
  {
    size_t count = 0;
    std::string msg;
    do
    {
      std::string msgHeader = std::string("msg #") + convert(++count) + " ";
      msg = Q_.deQ();
      sout << locker << "\n    dequeued " << msgHeader << msg << unlocker;
      ::Sleep(200);
    } while(msg != "quit");
    sout << "\n  Child thread quitting";
  }
private:
  BQueue<std::string>& Q_;  // note reference
};

void main()
{
  std::cout << "\n  Demonstrating Queued Message Passing";
  std::cout << "\n ======================================\n";

  BQueue<std::string> Q;
  ChildThreadProc tp(Q);
  thread t(tp);
  t.start();
  const size_t NUMMSGS = 7;
  std::string msgs[NUMMSGS] = { "first", "second", "third", "fourth", "fifth", "sixth", "quit" };
  for(size_t i=0; i<NUMMSGS; ++i)
  {
    sout << locker << "\n  enqueuing msg " << msgs[i] << unlocker;
    Q.enQ(msgs[i]);
    ::Sleep(100);
  }
  t.wait();
  sout << "\n  Application quitting\n\n";
}