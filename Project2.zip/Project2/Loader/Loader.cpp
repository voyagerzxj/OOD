///////////////////////////////////////////////////////////////
// Loader.cpp - Load files that matches patterns and regexs  //
// ver 1.0                                                   //
// Xiaojun Zhang, CSE687-Object Oriented Design, Spring 2019 //
///////////////////////////////////////////////////////////////

#include "Loader.h"
#include "../FileMgr/FileMgr.h"
#include "../FileSystem/FileSystem.h"
#include <regex>
#include <iostream>

using namespace FileManager;
std::vector<std::string> Loader::files_;

// -----< helper function, called when a file is found, add the file in to file list >-------------------------
struct FileHandler : IFileEventHandler
{
	void execute(const std::string& fileSpec)
	{
		//std::cout << "\n  --   " << fileSpec;
		Loader::files().push_back(fileSpec);
	}
};

// -----< helper function, called when a directory is found >-------------------------
struct DirHandler : IDirEventHandler
{
	void execute(const std::string& dirSpec)
	{
		//std::cout << "\n  ++ " << dirSpec;
	}
};

// -----< initialize Loader with rootDir, patterns, regular expressions >-------------------------
Loader::Loader(std::string & rootDir, std::vector<std::string>& patterns, std::vector<std::string>& regexes)
	:rootDir_(rootDir), patterns_(patterns), regexes_(regexes)
{
	setFileMgr();
}

// -----< set root directory >-------------------------
void Loader::setRootDir(std::string rootdir)
{
	rootDir_ = rootdir;
}

// -----< set patterns >-------------------------
void Loader::setPatterns(std::vector<std::string> patterns)
{
	patterns_ = patterns;
}

// -----< set regular expressions >-------------------------
void Loader::setRegexes(std::vector<std::string> regexes)
{
	regexes_ = regexes;
}

// -----< setup file manager which finds files in root dir matches patterns >-------------------------
void Loader::setFileMgr() { 
	fileMgr_ = FileManager::FileMgrFactory::create(rootDir_);
	auto fh = new FileHandler;
	auto dh= new DirHandler;
	fileMgr_->regForFiles(fh);
	fileMgr_->regForDirs(dh);
	for (auto pattern: patterns_)
	{
	fileMgr_->addPattern(pattern);
	}
}

// -----< select files in files_ that matches patterns, if no files matches, remain all files in files_ >-------------------------
bool Loader::match_regexes(const std::vector<std::string>& regexes)
{
	if (regexes.size() == 0) return false;
	std::vector<std::string> filteredFiles; // to store files matching regex
	for (auto file : files_) {
		std::string filename = FileSystem::Path::getName(file);
		for (auto regex : regexes) {
			std::regex r(regex);
			if (std::regex_match(filename, r)) {
				filteredFiles.push_back(file);
				break; // break to avoid adding same file twice to the  
					   // list in case it matches multiple regexes
			}
		}
	}
	if (filteredFiles.size() > 0) { // found files matching regex?
		files_ = filteredFiles;
		return true;
	}
	std::cout << "No file matches regular expressions." << std::endl;
	return false;
}

// -----< find files in root dir that matches patternes , and regexes if possible >-------------------------
void Loader::extractFiles()
{
	setFileMgr();
	fileMgr_->search();
    match_regexes(regexes_);
}

// -----< return file list which contains all the files found >-------------------------
std::vector<std::string>& Loader::files()
{
	return files_;
}

#ifdef TEST_LOADER
// -----< test stub for loader class >-----------------------------------
int main() {	
	Loader testLoader;

	std::vector<std::string> reg;
	reg.push_back("[A-C](.*)");
	testLoader.setRegexes(reg);

	std::vector<std::string> patt;
	patt.push_back("*.cpp");
	testLoader.setPatterns(patt);

	std::cout << "****We are searching from directory: " << FileSystem::Path::getFullFileSpec("..") << std::endl;
	testLoader.setRootDir(FileSystem::Path::getFullFileSpec(".."));
	
	testLoader.setFileMgr();
	testLoader.extractFiles();

	std::cout << "****Found files:" << std::endl;
	for (auto f : testLoader.files()) {
		std::cout << f << std::endl;
	}
}
#endif
