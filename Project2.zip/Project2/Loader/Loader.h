#ifndef LOADER_H
#define LOADER_H
///////////////////////////////////////////////////////////////
// Loader.h - Load files that matches patterns and regexs    //
// ver 1.0                                                   //
// Xiaojun Zhang, CSE687-Object Oriented Design, Spring 2019 //
///////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package contains one class: Loader.
 * Its purpose is to find files under given root directory whose
 * file name matches any of the given patterns. 
 * Further more, if regular expressions are given. Files matches
 * any of the regular expressions will remained if such file exists.
 * The found filenames is stored in a vector.
 * It is implemented using IFileMgr Interface.
 *
 * Required Files:
 * ---------------
 * Loader.h, Loader.cpp, IFileMgr.h, FileSystem.h
 *
 * Build Process:
 * --------------
 * devenv Project2.sln /rebuild debug
 *
 * Maintenance History:
 * --------------------
 * ver 1.0 : 05 Mar 2019
 * - first release
 *
 */

#include<vector>
#include<string>
#include "../FileMgr/IFileMgr.h"

class Loader 
{
public:
	//default constructor
	Loader() {};

	//initialize Loader with rootDir, patterns, regular expressions.
	Loader(std::string &rootDir, std::vector<std::string> &patterns, std::vector<std::string> &regexes);
	
	//destructor
	~Loader() { delete fileMgr_; };

	//set patterns
	void setPatterns(std::vector<std::string> patterns);

	//set regexes
	void setRegexes(std::vector<std::string> regexes);
	
	//set root directory
	void setRootDir(std::string rootdir);

	//setup file manager to find files in root dir matches patterns
	void setFileMgr();
	
	//return reference to list of file to be processed
	static std::vector<std::string>& files();
	
	//find files in root dir that matches patternes and regexes. 
	//if no file matches regex, it will get all files that matches patterns 
	void extractFiles();

private:
	//stores the files to be processed
	static std::vector<std::string> files_;
	
	//search root dir
	std::string rootDir_;
	
	//patterns
	std::vector<std::string> patterns_;
	
	//regexes
	std::vector<std::string> regexes_;
	
	//point to a file manager, used to extract files
	FileManager::IFileMgr* fileMgr_;
		
	//select files in files_ that matches patterns, if no files matches, remain all files in files_ 
	bool match_regexes(const std::vector<std::string>& regexes);
};
#endif