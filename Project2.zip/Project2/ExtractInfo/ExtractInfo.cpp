///////////////////////////////////////////////////////////////
// ExtractInfo.cpp- Extract Dependency information and       //
//                 information about special lines from      //
//                 a single file or a list of files          //
// ver 1.0                                                   //
// Xiaojun Zhang, CSE687-Object Oriented Design, Spring 2019 //
///////////////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include "ExtractInfo.h"
#include "../FileSystem/FileSystem.h"
#include "../Parser/ConfigureParser.h"

using namespace Lexer;
using namespace CodeAnalysis;

// -----< Extract information from a single file >-------------------------
// the result is returned as a temporary pair
// the first of the pair is a map that mapping line number to details about the line
// the second of the pair is a vector that holds what files this file depends on. 
FileInfoPair ExtractInfo::ExtractSingleFileInfo(std::string fileSpec) {
	fileSpec = FileSystem::Path::getFullFileSpec(fileSpec);
	std::cout << "*****Extracting info from: " << fileSpec << std::endl;
	std::map<int, LineInfo> singleFileInfo;
	std::vector<std::string> dependFiles;
	ExtractSingleFileDefinitionInfo(fileSpec, singleFileInfo, dependFiles);
	ExtractSingleFileCommentInfo(fileSpec, singleFileInfo);
	return std::make_pair(singleFileInfo, dependFiles);
}

// -----< Extract information from a list of files >-------------------------
// store the result in data members (fileInfoMap, dpTable).
void ExtractInfo::ExtractFileInfo(std::vector<std::string> fileList)
{
	for (auto file : fileList) {
		FileInfoPair fileInfoPair = ExtractSingleFileInfo(file);
		std::string filename = FileSystem::Path::getName(file);
		fileInfoMap[filename] = fileInfoPair.first;
		for (auto depfile : fileInfoPair.second) {
			dpTable.addDependency(file, depfile);
		}
	}
}


// -----< Extract the information of special lines from a file >-------------------------
// It takes the last two arguments by reference. The result is written directly to these two arguements
// !!!Note!!! It configures the parser to take no comments. The parser will give the right results about start/end line
// of class/struct/functions.
void ExtractInfo::ExtractSingleFileDefinitionInfo(std::string fileSpec, std::map<int, LineInfo>& singleFileInfo, std::vector<std::string>& dependfile)
{
	ConfigParseForCodeAnal configure;
	configure.returnComment(false);
	Parser* pParser = configure.Build();
	std::string name;
	try
	{
		if (pParser)
		{
			name = FileSystem::Path::getName(fileSpec);
			if (!configure.Attach(fileSpec))
			{
				std::cout << "\n  Could not open file " << name << std::endl;
				throw("Could not open file");
			}
		}
		else
		{
			std::cout << "\n  Parser not built\n";
			throw("Parser not built");
		}
		Repository* pRepo = Repository::getInstance();// save current package name
		pRepo->package() = name;
		while (pParser->next())// parse the package
		{
			pParser->parse();
		}
		ASTNode* pGlobalScope = pRepo->getGlobalScope();// final AST operations
		complexityEval(pGlobalScope);// walk AST, computing complexity for each node and record in AST node's element
		extractDependencies(dependfile, pGlobalScope);
		extractDefinition(singleFileInfo, pGlobalScope);
	}
	catch (std::exception& ex)
	{
		std::cout << "\n\n    " << ex.what() << "\n\n";
		std::cout << "\n  exception caught at line " << __LINE__ << " ";
		std::cout << "\n  in package \"" << name << "\"";
	};
}

// -----< Extract the information of comments from a file >-------------------------
// It takes the last one argument by reference. The result is written directly to the arguement
// !!!Note!!! It configures the parser to take comments. The parser will give the right results about start/end line
// of comments.
void ExtractInfo::ExtractSingleFileCommentInfo(std::string fileSpec, std::map<int, LineInfo>& singleFileInfo)
{
	ConfigParseForCodeAnal configure;
	configure.returnComment(true);
	Parser* pParser = configure.Build();
	std::string name;
	try
	{
		if (pParser)
		{
			name = FileSystem::Path::getName(fileSpec);
			if (!configure.Attach(fileSpec))
			{
				std::cout << "\n  Could not open file " << name << std::endl;
				throw("Could not open file");
			}
		}
		else
		{
			std::cout << "\n  Parser not built\n";
			throw("Parser not built");
		}
		Repository* pRepo = Repository::getInstance();// save current package name
		pRepo->package() = name;
		while (pParser->next())// parse the package
		{
			pParser->parse();
		}
		ASTNode* pGlobalScope = pRepo->getGlobalScope();// final AST operations
		complexityEval(pGlobalScope);// walk AST, computing complexity for each node and record in AST node's element
		extractComments(singleFileInfo, pGlobalScope);
	}
	catch (std::exception& ex)
	{
		std::cout << "\n\n    " << ex.what() << "\n\n";
		std::cout << "\n  exception caught at line " << __LINE__ << " ";
		std::cout << "\n  in package \"" << name << "\"";
	}
}


// -----< helper function: get the include file info from a token collection>-------------------------
std::string ExtractInfo::getIncludeFile(ITokenCollection* statement)
{
	TokColl includeToks{ "#", "include" };
	if (!(statement->hasSequence(includeToks)))
			return "";
	size_t pPos;
	statement->find("include", pPos);
	//must have something afer #include
	if (pPos >= ((statement->size())-1))
		return "";
	//we only record user-defined files. Ignore std libs.
    if (statement->contains("<") || (statement->contains(">")))
		return "";
    std::string depFile = (*statement)[pPos + 1];
	depFile = depFile.substr(1, depFile.size()-2);
	depFile = FileSystem::Path::getName(depFile);
	return depFile;
}

// -----< Extract dependency information from a single file's global AST node >-------------------------
void ExtractInfo::extractDependencies(std::vector<std::string>& dependFiles, CodeAnalysis::ASTNode * pGlobalScope)
{
	for (auto statement : pGlobalScope->statements_)
	{
		std::string includefile = getIncludeFile(statement);
		if (includefile == "") continue;
		std::cout << "   >> depend on: " << includefile << std::endl;
		dependFiles.push_back(includefile);
		
	}
}

// -----< Extract Class/Function/Struct definition information by walking through a single file's ASTree >-------------------------
void ExtractInfo::extractDefinition(std::map<int, LineInfo> &filenode, CodeAnalysis::ASTNode * pGlobalScope)
{
	std::function<void(ASTNode*, size_t)> co = [&, this](ASTNode* pNode, size_t indentLevel)
	{
		if (((pNode->type_) == "class") || ((pNode->type_) == "struct")) {
			std::cout << "   >> class start at line: " << pNode->startLineCount_ << std::endl;
			filenode[pNode->startLineCount_].isClassStartline = true;
			std::cout << "   >> class end at line: " << pNode->endLineCount_ << std::endl;
			filenode[pNode->endLineCount_].isClassEndline = true;
		}
		else if ((pNode->type_) == "function") {
			std::cout << "   >> function start at line: " << pNode->startLineCount_ << std::endl;
			filenode[pNode->startLineCount_].isFunctionStartline = true;
			std::cout << "   >> function end at line: " << pNode->startLineCount_ << std::endl;
			filenode[pNode->endLineCount_].isFunctionEndline = true;
		}
	};
	ASTWalk(pGlobalScope, co);
}


// -----< Extract Comment information from a single file's global AST node >-------------------------
void ExtractInfo::extractComments(std::map<int, LineInfo>&filenode, CodeAnalysis::ASTNode * pGlobalScope)
{
	for (auto comment : pGlobalScope->comm_)
	{
		filenode[comment.startline_].containsComments = true;
		filenode[comment.endline_].containsComments = true;
		if (comment.comment_[1] == '/') {    //This is a single line comment
			std::cout << "   >> single line comment at line: " << comment.startline_ << std::endl;
			filenode[comment.startline_].singleLineComment=comment.comment_;
		}
		else { //This is a multi-line comment
			size_t pos,rpos;
			pos = comment.comment_.find('\n');
			std::cout << "   >> multi line comment at line: " << comment.startline_ << std::endl;
			if (pos == std::string::npos) //This is a multi-line comment but occupies only single line
			{
				filenode[comment.startline_].startMultiLineComments.push_back(comment.comment_);
				filenode[comment.endline_].endMultiLineComments.push_back(comment.comment_);
			}
			else  //This is a multi-line comment that occupies multiple lines
			{ 
			rpos= comment.comment_.rfind('\n');
			std::string firstline = comment.comment_.substr(0, pos);
			std::string lastline = comment.comment_.substr(rpos+1, comment.comment_.size()-rpos-1);
			filenode[comment.startline_].startMultiLineComments.push_back(firstline);
			filenode[comment.endline_].endMultiLineComments.push_back(lastline);
			}
		}
	}
}



// -----< get file info map >-------------------------
std::unordered_map<std::string, std::map<int, LineInfo>>& ExtractInfo::getFileInfoMap()
{
	return fileInfoMap;
}


// -----< get dependency table >-------------------------
DependencyTable& ExtractInfo::getDependencyTable()
{
	return dpTable;
}

#ifdef TEST_EXTRACTINFO
// -----< test stub for extractinfo class >-----------------------------------
int main()
{
	ExtractInfo infoExtractor;
	//test single file
	std::string singleTestFile = "../TestFiles/DirExplorerN.h";
	std::cout << "*****Testing single file:" << singleTestFile<< std::endl;
    FileInfoPair testPair = infoExtractor.ExtractSingleFileInfo(singleTestFile);
	auto lineInfoMap = testPair.first;
	for (auto line: lineInfoMap)
	{std::cout << "Line number:" << line.first<<std::endl;
	if (line.second.isClassStartline) std::cout << "is a start line of a class" << std::endl;
	if (line.second.isClassEndline) std::cout << "is an end line of a class" << std::endl;
	if (line.second.isFunctionStartline) std::cout << "is a start line of a function" <<  std::endl;
	if (line.second.isFunctionEndline) std::cout << "is an end line of a function" << std::endl;
	if (line.second.containsComments) std::cout << "contains comments" <<  std::endl;
	}
	//test multiple files
	std::vector<std::string> testfiles{ "../TestFiles/DirExplorerN.h" ,"../TestFiles/DirExplorerN.cpp" };
	std::cout << "*****Testing multi files:" << "../TestFiles/DirExplorerN.h" <<" and " << "../TestFiles/DirExplorerN.cpp" << std::endl;
	infoExtractor.ExtractFileInfo(testfiles);
	auto dptable=infoExtractor.getDependencyTable();
	for (auto entry : dptable) {
		std::cout<<"File: "<< entry.first <<" depends on: ";
		for (auto dep : entry.second)
			std::cout << dep;
		std::cout << std::endl;
	}
}
#endif