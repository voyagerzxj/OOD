#ifndef LINEINFO
#define LINEINFO
///////////////////////////////////////////////////////////////
// LineInfo.h - LineInfo data structure holds properties of  //
//              each line of a file                          //
// ver 1.0                                                   //
// Xiaojun Zhang, CSE687-Object Oriented Design, Spring 2019 //
///////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This file contains one struct: LineInfo.
 * Its purpose is to record what each line in a file is/has.
 * See comments in the structure for more info.
 * It is not robust because:
 * 1. each line can be the start/end line of multiple class/functions. 
 *    this structure cannot tell you these details.
 * 2. it uses string to record what the comments are. But it is possible
 *    that a line contains quotes that has the same contents in it;
 *    or a line may have multiple comments that has same content;
 *    or the comment content is the same as other part of the line which is not comment.
 *
 * Required Files:
 * ---------------
 * LineInfo.h
 *
 * Build Process:
 * --------------
 * devenv Project2Starter.sln /rebuild debug
 *
 * Maintenance History:
 * --------------------
 * ver 1.0 : 05 Mar 2019
 * - first release
 *
 */
#include <string>
#include <vector>

struct LineInfo
{
	//is start line of a class
	bool isClassStartline=false; 
	//is end line of a class
	bool isClassEndline = false;
	//is start line of a function
	bool isFunctionStartline = false;
    //is end line of a function
	bool isFunctionEndline = false;
	//does this line has comments
	bool containsComments = false;
	//if it has single line comment, what is it
	std::string singleLineComment;
	//if it contains start line(s) of multi-line comment(s), what is it/are they
	std::vector<std::string> startMultiLineComments;
	//if it contains end line(s) of multi-line comment(s), what is it/are they
	std::vector<std::string> endMultiLineComments;
};

#endif

