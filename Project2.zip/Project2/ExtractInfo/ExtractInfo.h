#ifndef EXTRACTINFO_H
#define EXTRACTINFO_H
///////////////////////////////////////////////////////////////
// ExtractInfo.h - Extract Dependency information and        //
//                 information about special lines from      //
//                 a single file or a list of files          //
// ver 1.0                                                   //
// Xiaojun Zhang, CSE687-Object Oriented Design, Spring 2019 //
///////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package contains one class: ExtractInfo. (and one struct: LineInfo)
 * Its purpose is to extract critical information from a file/files. 
 * The critical information for a file contains:
 * 1. Dependency information: what files does this file depend on
 *    It is analysed by reading the #include"...." part of each file which is
 *    recorded in the global node of the Abstract Syntax Tree.
 *    We record that information in a DependencyTable.
 * 2. Information of special lines (start/end lines of classes/structs/functions
 *    and lines that contains comments). Start/end lines are analysed by walking
 *    through the Abstract Syntax Tree. Comment info is analysed by info stored 
 *    in the global node of the tree.
 *    We record this information in a vector of LineInfo.
 * This class is implemented using Parser package to build the abstract syntax tree
 * for each file.
 *
 * Required Files:
 * ---------------
 * ExtractInfo.h, ExtractInfo.cpp, ITokenCollection.h, AbstrSynTree.h, 
 * DependencyTable.h, ConfigureParser.h, FileSystem.h
 *
 * Build Process:
 * --------------
 * devenv Project2.sln /rebuild debug
 *
 * Maintenance History:
 * --------------------
 * ver 1.0 : 05 Mar 2019
 * - first release
 *
 */
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <utility>
#include "LineInfo.h"
#include "../SemiExpression/ITokenCollection.h"
#include "../AbstractSyntaxTree/AbstrSynTree.h"
#include "../DependencyTable/DependencyTable.h"

using FileInfoPair = std::pair<std::map<int, LineInfo>, std::vector<std::string>>;

class ExtractInfo
{
public:
	// -----< default constructor >-------------------------
	ExtractInfo() {};

	// -----< destructor >-------------------------
	~ExtractInfo() {};

	// -----< Extract information from a list of files >-------------------------
	// store the result in data members (fileInfoMap, dpTable).
    void ExtractFileInfo(std::vector<std::string> fileList);

	// -----< Extract information from a single file >-------------------------
	// the result is returned as a temporary pair
	// the first of the pair is a map that mapping line number to details about the line
	// the second of the pair is a vector that holds what files this file depends on. 
	FileInfoPair ExtractSingleFileInfo(std::string fileSpec);

	// -----< Extract the information of special lines from a file >-------------------------
	// It takes the last two arguments by reference. The result is written directly to these two arguements
	void ExtractSingleFileDefinitionInfo(std::string fileSpec, std::map<int, LineInfo>& singleFileInfo, std::vector<std::string>& dependfile);
	
	// -----< Extract the information of comments from a file >-------------------------
	// It takes the last one argument by reference. The result is written directly to the arguement
	void ExtractSingleFileCommentInfo(std::string fileSpec, std::map<int, LineInfo>& singleFileInfo);
	
	// -----< get the rusulted File Info Map >-------------------------
	// This map maps each file to a LineInfo.
	std::unordered_map<std::string, std::map<int, LineInfo>>& getFileInfoMap();
	
	// -----< get the  dependency table >-------------------------
	// This dependency table maps each file to a list of files that it depends on.
	DependencyTable& getDependencyTable();

private:
	//The map that maps a file to another map which maps each line of the file to its LineInfo details.
	std::unordered_map<std::string, std::map<int, LineInfo>> fileInfoMap;
	
	//This dependency table maps each file to a list of files that it depends on.
	DependencyTable dpTable;

	// -----< helper function: get the include file info from a token collection>-------------------------
	std::string getIncludeFile(Lexer::ITokenCollection* statement);
	
	// -----< get dependency information of a file by analysing its global node of ASTree >-------------------------
	void extractDependencies(std::vector<std::string>& dependFiles, CodeAnalysis::ASTNode* pGlobalScope);

	// -----< get special line information of a file by analysing walking through its ASTree >-------------------------
	void extractDefinition(std::map<int, LineInfo> &filenode, CodeAnalysis::ASTNode* pGlobalScope);

	// -----< get comment information of a file by analysing its global node of ASTree >-------------------------
	void extractComments(std::map<int, LineInfo> &filenode, CodeAnalysis::ASTNode* pGlobalScope);
};
#endif