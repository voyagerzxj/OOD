///////////////////////////////////////////////////////////////
// Executive.cpp-parse command line, find/analyse/convert    //
//               intended files                              //
// ver 1.0                                                   //
// Xiaojun Zhang, CSE687-Object Oriented Design, Spring 2019 //
///////////////////////////////////////////////////////////////

#include "Executive.h"
#include "../FileSystem/FileSystem.h"

using namespace Utilities;

// -----< destructor >----------------------------
Executive::~Executive()
{
	delete CmdProcessor;
	delete FileLoader;
	delete InfoExtractor;
	delete CodeToWebConverter;
}

// -----< set working directory >----------------------------
void Executive::workingDirectory(const std::string & dir)
{
	dirIn_ = FileSystem::Path::getFullFileSpec(dir);
}

// -----< get working directory >----------------------------
const std::string & Executive::workingDirectory() const
{
	return dirIn_;
}

// -----< set output directory >-----------------------------------------
void Executive::outputDirectory(const std::string & dir)
{
	dirOut_ = dir;
}

// -----< get output directory >--------------------------------------
const std::string & Executive::outputDirectory() const
{
	return dirOut_;
}

// -----< command line usage >----------------------------------------------
ProcessCmdLine::Usage customUsage()
{
	std::string usage;
	usage += "\n  Command Line: path [/option]* [/pattern]* [/regex]*";
	usage += "\n    path is relative or absolute path where processing begins";
	usage += "\n    [/option]* are one or more options of the form:";
	usage += "\n      /s     - walk directory recursively";
	usage += "\n      /demo  - run in demonstration mode (cannot coexist with /debug)";
	usage += "\n      /debug - run in debug mode (cannot coexist with /demo)";
	usage += "\n    [pattern]* are one or more pattern strings of the form:";
	usage += "\n      *.h *.cpp *.cs *.txt or *.*";
	usage += "\n    [regex] regular expression(s), i.e. [A-B](.*)";
	usage += "\n";
	return usage;
}

// -----< parse command line args to get input dir, pattern, regex >----------------------------------------------
bool Executive::processCommandLineArgs(int argc, char ** argv)
{
	CmdProcessor = new ProcessCmdLine(argc, argv);
	CmdProcessor->usage(customUsage());
	preface("Command Line: ");
	CmdProcessor->showCmdLine();
	if (CmdProcessor->parseError())
	{
		CmdProcessor->usage();
		std::cout << "\n\n";
		return false;
	}
	workingDirectory(CmdProcessor->path());
	for (auto patt : CmdProcessor->patterns())
	{
		patts_.push_back(patt);
	}
	for (auto reg : CmdProcessor->regexes())
	{
		regexes_.push_back(reg);
	}
	return true;
}


// -----< get file spec list according to input dir, pattern, regex >----------------------------------------------
void Executive::setFilesToProcess()
{
	std::cout << "\n\n### Searching files......" << std::endl;
	FileLoader = new Loader(dirIn_, patts_, regexes_);
	FileLoader->extractFiles();
	files_ = FileLoader->files(); 
	std::cout << "*****Found files:" << std::endl;
	for (auto f : files_) {
		std::cout << f << std::endl;
	}
	std::cout  << std::endl;
}

// -----< set dependency table and file info map for selected files >----------------------------
void Executive::setFilesInfo()
{
	std::cout << "### Extracting info from all files......" << std::endl;
	InfoExtractor = new ExtractInfo;
	InfoExtractor->ExtractFileInfo(files_);
	fileInfoMap = InfoExtractor->getFileInfoMap();
	dpTable = InfoExtractor->getDependencyTable();
}

// -----< convert all the selected files into webpage according to the extracted file info >----------------------------
void Executive::convertFiles()
{
	std::cout << "### Converting all files......" << std::endl;
	CodeToWebConverter = new CodeConverter(dpTable, fileInfoMap);
	CodeToWebConverter->setOutputDir(dirOut_);
	convertedFiles_ = CodeToWebConverter->convert();
	std::cout<< "\n### Please check the following output files:" << std::endl;
	for (auto f : convertedFiles_) {
		std::cout << f << std::endl;
	}
	std::cout << std::endl;
	std::cout << "\n !!!Note!!! I listed all the depended files in the Dependency File part." << std::endl;
	std::cout << " But superlinks are created only for the files in the output directory." << std::endl;
}



int main(int argc, char ** argv)
{
	Executive testEXE;
	testEXE.processCommandLineArgs(argc, argv);
	testEXE.setFilesToProcess();
	testEXE.setFilesInfo();
	testEXE.convertFiles();
}