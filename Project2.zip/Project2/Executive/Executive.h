#ifndef EXECUTIVE_H
#define EXECUTIVE_H
///////////////////////////////////////////////////////////////
// Executive.h - parse command line, find/analyse/convert    //
//               intended files                              //
// ver 1.0                                                   //
// Xiaojun Zhang, CSE687-Object Oriented Design, Spring 2019 //
///////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package contains one class: Executive.
 * It combines all the funtions in this project to produce the result.
 * Its purpose is to:
 * 1. parse command line arguments
 * 2. use loader to Finds and loads files for Processing from a directory tree
 * 3. use extractinfo to records file dependencies/info for each processed file
 * 4. use convert to convert each file into webpage
 *
 * Required Files:
 * ---------------
 * Executive.h, Executive.cpp, Loader.h, LineInfo.h, ExtractInfo.h, DependencyTable.h,
 * Converter.h, CodeUtilities.h, FileSystem.h
 *
 * Build Process:
 * --------------
 * devenv Project2.sln /rebuild debug
 *
 * Maintenance History:
 * --------------------
 * ver 1.0 : 05 Mar 2019
 * - first release
 *
 */

#include "../CodeUtilities/CodeUtilities.h"
#include "../Loader/Loader.h"
#include "../ExtractInfo/LineInfo.h"
#include "../ExtractInfo/ExtractInfo.h"
#include "../DependencyTable/DependencyTable.h"
#include "../Converter/Converter.h"
#include <string>
#include <vector>

class Executive {
public:
	// -----< constructor >----------------------------
	Executive() {};

	// -----< destructor >----------------------------
	~Executive();

	// -----< set working directory >----------------------------
	void workingDirectory(const std::string& dir);

	// -----< get working directory >----------------------------
	const std::string& workingDirectory() const;

	// -----< set output directory >----------------------------
	void outputDirectory(const std::string& dir);

	// -----< get output directory >----------------------------
	const std::string& outputDirectory() const;

	// -----< process command line to get input directory, patterns, regular expressions. >----------------------------
	bool processCommandLineArgs(int argc, char ** argv);

	// -----< set which files are to be processed according patterns and regular exps in the input directory. >----------------------------
	void setFilesToProcess();

	// -----< set dependency table and file info map for selected files >----------------------------
	void setFilesInfo();

	// -----< convert all the selected files into webpage according to the extracted file info >----------------------------
	void convertFiles();

private:
	//Tools to do the jobs
    //parse cmdline
	Utilities::ProcessCmdLine *CmdProcessor; 

    //find files to process
	Loader* FileLoader; 

	//extract info from files
	ExtractInfo* InfoExtractor;

	//convert the files according to the info extracted
    CodeConverter* CodeToWebConverter;

	//input folder
	std::string dirIn_;

	//output folder
	std::string dirOut_ = "..\\ConvertedWebpages\\";

	//regular expression from command line 
	std::vector<std::string> regexes_;

	//patterns from command line
	std::vector<std::string> patts_;

	//files to be processed
	std::vector<std::string> files_;

	//converted files
	std::vector<std::string> convertedFiles_;

	//container which holds file to fileinfo mapping
	//file info contains what does each line contains
	DependencyTable dpTable;
	std::unordered_map<std::string, std::map<int, LineInfo>> fileInfoMap;
};
#endif