#ifndef CONVERTER_H
#define CONVERTER_H
////////////////////////////////////////////////////////////////
// Converter.h - defines source code conversion to webpage    //
//               with hide/show class/funtion/comment features//
// ver 1.0                                                    //
// Xiaojun Zhang, CSE687-Object Oriented Design, Spring 2019  //
////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 *  This package defines CodeConverter class which accepts DependencyTable
 *  and FileInfoMap, to create a webpage for each file through the following:
 *  1. The conversion process filters HTML special characters.
 *  2. Create superlinks that point to the files that the file depends on.
 *  3. add <span> tags to enable hide/show features 
 *  4. surround the result with HTML template
 *  The resulting output of this converter is a list of files (vector<string>)
 *  of the created webpages.
 *
 * Required Files:
 * ---------------
 * Converter.h, Converter.cpp, LineInfo.h, DependencyTable.h, FileSystem.h
 *
 * Build Process:
 * --------------
 * devenv Project2.sln /rebuild debug
 *
 * Maintenance History:
 * --------------------
 * ver 1.0 : 05 Mar 2019
 * - first release
 */

#include <vector>
#include <string>
#include <fstream>
#include <map>
#include <unordered_map>
#include "../ExtractInfo/LineInfo.h"
#include "../DependencyTable/DependencyTable.h"

class CodeConverter
{
public:
  // -----< default ctor >--------------------------------------------------
  CodeConverter();

  // -----< ctor to set dep table , fileinfomap  >--------------------------------------------------
  CodeConverter(const DependencyTable& dt, const std::unordered_map<std::string, std::map<int, LineInfo>> &InfoMap);

  // -----< set dependency table function >---------------------------------
  void setDepTable(const DependencyTable& dt);
 
  // -----< set file info map function >---------------------------------
  void setFileInfoMap(std::unordered_map<std::string, std::map<int, LineInfo>> InfoMap);

  // -----< set output directory >--------------------------------------------
  void setOutputDir(const std::string& dir);

  // -----< convert pre-set dependency table and file info map >------------------------------
  std::vector<std::string> convert();

  // -----< convert single file given path >----------------------------------
  std::string convert(const std::string& filepath);

  // -----< convert files in the file list >----------------------------------
  std::vector<std::string> convert(const std::vector<std::string>& files);

  // -----< get list of converted files >-------------------------------------
  const std::vector<std::string> convertedFiles() const;
  
private:
  // -----< create output directory >-----------------------------------------
  bool createOutpurDir();

  // -----< private - read file and create webpage >--------------------------
  // This is the "core" function that translate a c++ source code file into webpage
  // using addPreCodeHTML,addPreTag, addDependencyLinks, addClosingTags,
  // skipSpecialChars, HandleSpecialLine
  bool convertFile(std::string file);

  // -----< add generic HTML preliminary markup >-------------------
  void addPreCodeHTML(const std::string& title);

  // -----< add pre tag >------------------------------------------
  // <pre> seperated into seperate function to allow for dependencies addition
  // before the actual code of the file 
  void addPreTag();

  // -----< add depedency links markup code >----------------------
  // in my implementation, all files depended is shown in the list
  // but only those exists in the output dir will has a link
  void addDependencyLinks(std::string file);

  // -----< add generic HTML markup closing tags >-----------------
  void addClosingTags();

  // -----< replace HTML special chars >---------------------------
  //note: the function uses while loop to make sure ALL special characters
  //are replaced instead of just the first encounter.  
  void skipSpecialChars(std::string& line);

  // -----< insert span tags where appropriate >---------------------------
  //the function uses information in fileinfomap to add <span> tags where
  //a class/function/struct starts/ends.  
  std::string HandleSpecialLine(std::string line, LineInfo infoNode);

  // -----< insert span tags where appropriate >---------------------------
  //the function uses information in fileinfomap to add <span> tags where
  //a comment starts/ends.  
  std::string HandleComment(std::string line, LineInfo infoNode);

  // -----< clear list of converted files and dependency table >-------------------------------------
  void clear();

private:
  //dependency table
  DependencyTable dt_;
  //file info map
  std::unordered_map<std::string, std::map<int, LineInfo>> fileInfoMap;
  //output dir
  std::string outputDir_ = "..\\ConvertedWebpages\\";
  //output file stream
  std::ofstream out_;
  //converted files
  std::vector<std::string> convertedFiles_;
};
#endif

