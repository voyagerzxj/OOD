///////////////////////////////////////////////////////////////
// client.cpp - Demonstrate Programming to Interface
//
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2005
///////////////////////////////////////////////////////////////
// Build Process:
///////////////////////////////////////////////////////////////
// This workspace contains three projects:
//   testv1 - Defines CTest version 1.0 built as library dll
//   testv2 - Defines CTest version 2.0 built as library dll
//   client - implicitly loads one of these test libraries
//
// Each testv? project builds its dll in the debug directory
// of the client, where the client can load it.
// Rebuild testv1, then client
// Run the client without rebuilding - see version 1.0 message
// Rebuild testv2
// Run the client without rebuilding - see version 2.0 message
//
// Note:
//   For this demo to work correctly you must follow the steps
//   above and:
//     CLICK NO ON THE DIALOG THAT TELLS YOU THE PROJECT
//     CONFIGURATION(S) ARE OUT OF DATE AND DO YOU WANT
//     TO REBUILD.
//   The demo is trying to show you that the client does not
//   have to be rebuilt.  Just copy the new test dll into the
//   client's bin\debug directory, which is done automatically
//   because I set up the project properties to deposit the
//   new dll into the clients bin\debug.
///////////////////////////////////////////////////////////////

#include <iostream>
#include "../test/test.h"

template <char ch='='>
class title
{
public:
  typedef std::string str;
  std::string operator()(const str &msg)
  {
    str underline(msg.length()+2,ch);
    return str("\n  ") + msg + str("\n ") + underline + str("\n");
  }
};
int main()
{
  std::cout << title<>()("Testing Interface and Factory");
  try
  {
    CTest* pCTest = CTest::CreateCTestImpl();
    pCTest->addString("\n  first string");
    pCTest->addString("\n  second string");
    std::cout << pCTest->ident();
    std::cout << pCTest->getString();
    std::cout << "\n  sizeof CTest instance is " 
              << pCTest->size() << " bytes";
    std::cout << "\n\n";
  }
  catch(std::exception& e)
  {
    std::cout << e.what();
  }
}
