///////////////////////////////////////////////////////////////
// test.cpp - Defines CTestImpl, derived from CTest
// version 1.0
//
// - Create as Win32 Project: Application Settings = DLL
// - Set Properties\C/C++\Code Generation\Runtime Library
//   to the value: Multi-threaded Debug DLL
// - Set Properties\Linker\Output File
//   to the value: ../client/debug/test.dll

#include "stdafx.h"
#include "test.h"
BOOL APIENTRY DllMain(
  HANDLE hModule, 
  DWORD  ul_reason_for_call, 
  LPVOID lpReserved
)
{
  switch (ul_reason_for_call)
  {
  case DLL_PROCESS_ATTACH:
  case DLL_THREAD_ATTACH:
  case DLL_THREAD_DETACH:
  case DLL_PROCESS_DETACH:
    break;
  }
    return TRUE;
}

class CTestImpl : public CTest
{
public:
  virtual ~CTestImpl() {}
  std::string ident();
  void addString(const std::string &str);
  std::string getString();
  int size();
private:
  std::string _str;
};

std::string CTestImpl::ident()
{
  return "CTest : version 1.0";
}

CTest* CTest::CreateCTestImpl() { return new CTestImpl(); }

void CTestImpl::addString(const std::string &str)
{
  _str += str;
}

std::string CTestImpl::getString()
{
  return _str;
}

int CTestImpl::size()
{
  return sizeof(*this);
}