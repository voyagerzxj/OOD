#ifndef TEST_H
#define TEST_H
///////////////////////////////////////////////////////////////
// test.h - Declares CTest Interface
// 
// Note: you must build with dll versions of RunTime Libraries
//       Look at Project Properties\C/C++\Code Generation

#ifdef TEST_EXPORTS
#define TEST_API __declspec(dllexport)
#else
#define TEST_API __declspec(dllimport)
#endif

#include <string>

class TEST_API CTest {
public:
  virtual ~CTest() {}
  static CTest* CreateCTestImpl();
  virtual std::string ident()=0;
  virtual void addString(const std::string &str)=0;
  virtual std::string getString()=0;
  virtual int size() = 0;
};

#endif
